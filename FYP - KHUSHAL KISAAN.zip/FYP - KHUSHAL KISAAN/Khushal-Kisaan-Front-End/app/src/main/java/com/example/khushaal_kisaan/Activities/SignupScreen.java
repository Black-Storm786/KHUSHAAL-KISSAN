package com.example.khushaal_kisaan.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.example.khushaal_kisaan.ModelClass.Signup_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Login_Signup_Response_POJO_Class;
import com.example.khushaal_kisaan.R;
import com.example.khushaal_kisaan.Retrofit.RetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;
import com.google.android.material.snackbar.Snackbar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupScreen extends AppCompatActivity {
    EditText username,email,password,confirmpassword;
    ImageView eye, eye1;
    Endpoints endpoints;
    LinearLayout signuplayout,signupsublayout;
    LottieAnimationView signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_screen);;
        getWindow().setStatusBarColor(ContextCompat.getColor(SignupScreen.this, R.color.mainblue_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(SignupScreen.this, R.color.mainblue_color));
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        signuplayout = findViewById(R.id.signuplayout);
        signupsublayout = findViewById(R.id.signupsublayout);
        signupsublayout.setVisibility(View.GONE);
        signup = findViewById(R.id.signup);
        signup.setVisibility(View.GONE);
        confirmpassword = findViewById(R.id.confirmpassword);
        eye = findViewById(R.id.eye);
        eye1 = findViewById(R.id.eye1);
        onClickListeners();
        endpoints = RetrofitClient.getAPIService();
    }

    private void onClickListeners() {
        eye1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int inputType = password.getInputType();
                if (inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    // Hide the password
                    password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    // Show the password
                    password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                }
                // Move the cursor to the end of the text
                password.setSelection(password.getText().length());
            }
        });

        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int inputType = confirmpassword.getInputType();
                if (inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    // Hide the password
                    confirmpassword.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    // Show the password
                    confirmpassword.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                }
                // Move the cursor to the end of the text
                confirmpassword.setSelection(confirmpassword.getText().length());
            }
        });
    }

    public void gosignin(View view) {
        startActivity(new Intent(getApplicationContext(),LoginScreen.class));
    }

    public void register(View view) {
        String Username = username.getText().toString();
        String Email = email.getText().toString();
        String Password = password.getText().toString();
        String ConfirmPassword = confirmpassword.getText().toString();
        if (Username.isEmpty()){
            Snackbar snackbar = Snackbar.make(view,"Please enter your username",Snackbar.LENGTH_LONG);
            snackbar.show();
        }
        else if (Email.isEmpty()){
            Snackbar snackbar = Snackbar.make(view,"Please enter your email",Snackbar.LENGTH_LONG);
            snackbar.show();
        } else if (!Email.contains("@gmail.com")) {
            Snackbar snackbar = Snackbar.make(view,"Please correct your email",Snackbar.LENGTH_LONG);
            snackbar.show();
        } else if (Password.isEmpty()) {
            Snackbar snackbar = Snackbar.make(view,"Please enter your password",Snackbar.LENGTH_LONG);
            snackbar.show();
        } else if (Password.length()<6) {
            Snackbar snackbar = Snackbar.make(view,"please enter 6 digit password",Snackbar.LENGTH_LONG);
            snackbar.show();
        } else if (ConfirmPassword.isEmpty()) {
            Snackbar snackbar = Snackbar.make(view,"Please enter your confirm password",Snackbar.LENGTH_LONG);
            snackbar.show();
        } else if (!Password.equals(ConfirmPassword)) {
            Snackbar snackbar = Snackbar.make(view,"Please enterr correct confirm password",Snackbar.LENGTH_LONG);
            snackbar.show();
        }
        else {
            try {
                signup.setVisibility(View.VISIBLE);
                signupsublayout.setVisibility(View.VISIBLE);
                signuplayout.setVisibility(View.GONE);
                new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        Signup_Model_Class signup_model_class = new Signup_Model_Class(Username,Email,Password);
                        Call<Login_Signup_Response_POJO_Class> call = endpoints.postSignupData(signup_model_class);
                        call.enqueue(new Callback<Login_Signup_Response_POJO_Class>() {
                            @Override
                            public void onResponse(Call<Login_Signup_Response_POJO_Class> call, Response<Login_Signup_Response_POJO_Class> response) {
                                System.out.println("User created successfully");
                                if (response.isSuccessful()){
                                    signup.setVisibility(View.GONE);
                                    signupsublayout.setVisibility(View.GONE);
                                    Login_Signup_Response_POJO_Class loginSignup_response_pojo_class = response.body();
                                    SharedPreferences sharedPreferences = getSharedPreferences("my_token",Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("auth_token", loginSignup_response_pojo_class.getAuth_token());
                                    editor.apply();
                                    Snackbar snackbar = Snackbar.make(view, loginSignup_response_pojo_class.getMsg(),Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                    startActivity(new Intent(getApplicationContext(),LoginScreen.class));
                                }
                                else{
                                    Snackbar snackbar = Snackbar.make(view,"In Else",Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                    signup.setVisibility(View.GONE);
                                }
                            }

                            @Override
                            public void onFailure(Call<Login_Signup_Response_POJO_Class> call, Throwable t) {
                                Snackbar snackbar = Snackbar.make(view,"In failure",Snackbar.LENGTH_LONG);
                                snackbar.show();
                                signup.setVisibility(View.GONE);
                            }
                        });
                    }
                },4000);

            }
            catch (Exception e){
                Snackbar snackbar = Snackbar.make(view,e.getMessage(),Snackbar.LENGTH_LONG);
                snackbar.show();
                System.out.println("INSIDE EXCEPTION"+e.getMessage());
                signup.setVisibility(View.GONE);
            }
        }
    }
}