package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Planting_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Planting_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Planting_Adapter extends RecyclerView.Adapter<Planting_Adapter.ViewHolder> {
    Context context;
    ArrayList<Planting_ModelClass> plantingdata = new ArrayList<>();

    public Planting_Adapter(Context context, ArrayList<Planting_ModelClass> plantingdata) {
        this.context = context;
        this.plantingdata = plantingdata;
    }

    @NonNull
    @Override
    public Planting_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.planting_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Planting_Adapter.ViewHolder holder, int position) {
        holder.plantingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Planting_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",plantingdata.get(position).getImage());
                i.putExtra("subtitle",plantingdata.get(position).getSubtitle());
                context.startActivity(i);
            }
        });
        holder.planting_screen_image.setImageResource(plantingdata.get(position).getImage());
        holder.planting_screen_subtitle.setText(plantingdata.get(position).getSubtitle());

    }

    @Override
    public int getItemCount() {
        return plantingdata.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout plantingcard;
        ImageView planting_screen_image;
        TextView planting_screen_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            plantingcard = itemView.findViewById(R.id.plantingcard);
            planting_screen_image = itemView.findViewById(R.id.planting_screen_image);
            planting_screen_subtitle = itemView.findViewById(R.id.planting_screen_subtitle);
        }
    }
}
