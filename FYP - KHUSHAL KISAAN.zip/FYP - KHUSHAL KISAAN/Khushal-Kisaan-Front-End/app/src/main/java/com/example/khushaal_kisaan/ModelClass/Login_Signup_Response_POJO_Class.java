package com.example.khushaal_kisaan.ModelClass;

public class Login_Signup_Response_POJO_Class {

//    @SerializedName("status")
    String status;

//    @SerializedName("msg")
    String msg;

//    @SerializedName("auth_token")
    String auth_token;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getAuth_token() {
        return auth_token;
    }

    public void setAuth_token(String auth_token) {
        this.auth_token = auth_token;
    }

    public Login_Signup_Response_POJO_Class(String status, String msg, String auth_token) {
        this.status = status;
        this.msg = msg;
        this.auth_token = auth_token;
    }
}
