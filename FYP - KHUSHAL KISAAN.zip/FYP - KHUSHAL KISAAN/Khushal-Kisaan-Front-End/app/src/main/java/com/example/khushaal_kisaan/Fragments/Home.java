package com.example.khushaal_kisaan.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.khushaal_kisaan.Activities.Crop_Disease_Detector;
import com.example.khushaal_kisaan.Activities.User_Selected_Crops_Activity;
import com.example.khushaal_kisaan.Activities.Weather_Forecasting;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.WeatherResponse;
import com.example.khushaal_kisaan.R;
import com.example.khushaal_kisaan.Retrofit.WeatherRetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Home extends Fragment {


    private ImageSlider imgslider;
    private RelativeLayout relativeLayout;



    public Home() {
        // Required empty public constructor
    }

   RelativeLayout selected_crops;
    MaterialButton takepicture;
    Endpoints endpoints;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_home, container, false);


       endpoints = WeatherRetrofitClient.getApiService();
       Call<WeatherResponse> call = endpoints.getWeatherByCity("karachi","7a375ece40385a1f880073da367d42ec");
       call.enqueue(new Callback<WeatherResponse>() {
           @Override
           public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
               if (response.isSuccessful()){
                     WeatherResponse weatherResponse = response.body();
                     if (weatherResponse!=null){
                         double temperature = weatherResponse.getMain().getTemp() - 273.15;
                         System.out.println("This is Temperature: " + temperature + " °C");
                     }
               }
           }

           @Override
           public void onFailure(Call<WeatherResponse> call, Throwable t) {

           }
       });
//       Call<WeatherResponse> call = endpoints.getWeatherByCity("karachi","7a375ece40385a1f880073da367d42ec");
        imgslider = view.findViewById(R.id.imageSlider);
        takepicture = view.findViewById(R.id.takepicture);


        takepicture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(),Crop_Disease_Detector.class));
            }
        });
        selected_crops = view.findViewById(R.id.selected_crops);
        selected_crops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), User_Selected_Crops_Activity.class);
                getActivity().startActivity(intent);
            }
        });
        ArrayList<SlideModel> slideModels = new ArrayList<>();

        slideModels.add(new SlideModel("https://c0.wallpaperflare.com/preview/10/607/753/farm-sun-sunlight-background.jpg", ScaleTypes.FIT));
        slideModels.add(new SlideModel("https://thumbs.dreamstime.com/b/wheat-farm-background-wallpaper-abstract-vintage-sunset-65850813.jpg", ScaleTypes.FIT));
        slideModels.add(new SlideModel("https://cdn.wallpapersafari.com/64/83/VNc9FK.jpg", ScaleTypes.FIT));

        imgslider.setImageList(slideModels, ScaleTypes.FIT);


        relativeLayout = view.findViewById(R.id.weatherforecasting);

        relativeLayout.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), Weather_Forecasting.class);
               getActivity().startActivity(intent);
        });


        return  view;
    }
}