package com.example.khushaal_kisaan.Adaptors;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Harvesting_Adapter;
import com.example.khushaal_kisaan.R;

public class Community_Details_Screen_Adapter extends RecyclerView.Adapter<Community_Details_Screen_Adapter.ViewHolder> {
    @NonNull
    @Override
    public Community_Details_Screen_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.community_details_screen_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Community_Details_Screen_Adapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 10;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
