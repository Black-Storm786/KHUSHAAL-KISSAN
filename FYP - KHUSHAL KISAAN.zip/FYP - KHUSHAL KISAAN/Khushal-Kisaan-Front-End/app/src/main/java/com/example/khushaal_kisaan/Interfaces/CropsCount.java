package com.example.khushaal_kisaan.Interfaces;

public interface CropsCount {
    void set_crops_count(int num);
}
