package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Irrigation_Detail_Screen extends AppCompatActivity {
    ImageView back,irrigation_readmore_image;
    TextView irrigation_readmore_title,irrigation_readmore_subtitle,irrigation_readmore_date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_irrigation_detail_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        irrigation_readmore_image.setImageResource(image);
        irrigation_readmore_date.setText(date);
        irrigation_readmore_title.setText(title);
        irrigation_readmore_subtitle.setText(subtitle);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        irrigation_readmore_image = findViewById(R.id.irrigation_readmore_image);
        irrigation_readmore_title = findViewById(R.id.irrigation_readmore_title);
        irrigation_readmore_subtitle = findViewById(R.id.irrigation_readmore_subtitle);
        irrigation_readmore_date = findViewById(R.id.irrigation_readmore_date);

    }
}