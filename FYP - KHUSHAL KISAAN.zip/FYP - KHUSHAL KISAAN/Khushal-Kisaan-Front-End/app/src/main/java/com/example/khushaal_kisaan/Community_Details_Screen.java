package com.example.khushaal_kisaan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import com.example.khushaal_kisaan.Adaptors.Community_Details_Screen_Adapter;
import com.example.khushaal_kisaan.Retrofit.RetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;

public class Community_Details_Screen extends AppCompatActivity {
    RecyclerView communitydetailrecyclerview;
    Endpoints endpoints;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_community_details_screen);
        endpoints = RetrofitClient.getAPIService();
        Intent i = getIntent();
        String id = i.getStringExtra("id");
        initialization();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        communitydetailrecyclerview.setLayoutManager(linearLayoutManager);
        Community_Details_Screen_Adapter community_details_screen_adapter = new Community_Details_Screen_Adapter();
        communitydetailrecyclerview.setAdapter(community_details_screen_adapter);
    }

    private void initialization() {
        communitydetailrecyclerview = findViewById(R.id.communitydetailrecyclerview);
    }
}