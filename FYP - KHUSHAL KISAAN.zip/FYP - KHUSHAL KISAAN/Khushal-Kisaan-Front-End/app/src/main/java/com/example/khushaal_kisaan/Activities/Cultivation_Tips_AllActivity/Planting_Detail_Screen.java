package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Planting_Detail_Screen extends AppCompatActivity {
    ImageView back,planting_readmore_image;
    TextView planting_readmore_title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planting_detail_screen);
        initialization();
        onClickListeners();
        Intent i = getIntent();
        Integer image = i.getIntExtra("image",0);
        String subtitle = i.getStringExtra("subtitle");
        planting_readmore_image.setImageResource(image);
        planting_readmore_title.setText(subtitle);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void initialization() {
        back = findViewById(R.id.back);
        planting_readmore_image = findViewById(R.id.planting_readmore_image);
        planting_readmore_title = findViewById(R.id.planting_readmore_title);
    }

}