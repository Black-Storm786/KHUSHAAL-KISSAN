package com.example.khushaal_kisaan.Activities;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Adaptors.Languages_Adaptor;
import com.example.khushaal_kisaan.ModelClasses.Languages_Model_Class;
import com.example.khushaal_kisaan.Interfaces.LocaleListener;
import com.example.khushaal_kisaan.R;

import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocaleListener {

   // android.content.res.Resources res;
    private Context context;
    private ImageButton btn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //res = getResources();

        getWindow().setStatusBarColor(ContextCompat.getColor(MainActivity.this, R.color.maingrey_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(MainActivity.this, R.color.mainblue_color));

        context = getApplicationContext();
        RecyclerView recyclerView = findViewById(R.id.language_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        Languages_Model_Class[] myLanguageData = new Languages_Model_Class[]{
                new Languages_Model_Class("اردو","پشتو", "سندھی",R.drawable.pakistan,R.drawable.khyberpass,R.drawable.mazarequaid),
                new Languages_Model_Class("پنجابی", "بلوچی","English",R.drawable.tower,R.drawable.ziarat,R.drawable.english_icon),
        };

        Languages_Adaptor my_languageAdapter = new Languages_Adaptor(myLanguageData,MainActivity.this);
        my_languageAdapter.setLocaleListener(this);
        recyclerView.setAdapter(my_languageAdapter);

        btn = findViewById(R.id.continue_button);

        btn.setOnClickListener(v -> {
            Intent myIntent = new Intent(MainActivity.this, Crop_Selection_Activity.class);
            MainActivity.this.startActivity(myIntent);
            //finish();
        });


    }


    @Override
    public void setLocale(String lang) {
        Locale locale = new Locale(lang);
        Locale.setDefault(locale);
        Configuration configuration = new Configuration();
        configuration.locale = locale;
        //configuration.setLayoutDirection(Locale.ENGLISH);
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());
        recreate();
//        TextView view = findViewById(R.id.Select_Lang);
//        ViewGroup.MarginLayoutParams p = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
//        p.setMargins(40,0,210,20);
//        view.requestLayout();
    }

}