package com.example.khushaal_kisaan.Adaptors;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.khushaal_kisaan.Database.CardDatabase;
import com.example.khushaal_kisaan.Interfaces.CropsCount;
import com.example.khushaal_kisaan.ModelClass.InsertSelectedCardTask;
import com.example.khushaal_kisaan.ModelClass.SelectedCard;
import com.example.khushaal_kisaan.ModelClasses.Crops_Model_Class;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Crops_Adaptor extends RecyclerView.Adapter<Crops_Adaptor.ViewHolder>{

    Crops_Model_Class[] crops_model_class;
    Context context;
    private int crops_num=0,pos=0;
    private CropsCount cc;
    ArrayList<String> arrList = new ArrayList<String>();
    private CardDatabase database;
    private SharedPreferences sharedPreferences;

    public Crops_Adaptor(Crops_Model_Class[] crops_model_class, Context context) {
        this.crops_model_class = crops_model_class;
        this.context = context;
        database = Room.databaseBuilder(context, CardDatabase.class, "my_database").build();

        sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

    }




    @NonNull
    @Override
    public Crops_Adaptor.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.crops_selection_card_view,parent,false);
        Crops_Adaptor.ViewHolder viewHolder = new Crops_Adaptor.ViewHolder(view);
        return viewHolder;
    }




    @Override
    public void onBindViewHolder(@NonNull Crops_Adaptor.ViewHolder holder, int position) {

        final Crops_Model_Class my_crop_list = crops_model_class[position];
        holder.crop_text_view1.setText(my_crop_list.getCrop_name1());
        holder.crop_text_view2.setText(my_crop_list.getCrop_name2());
        holder.crop_text_view3.setText(my_crop_list.getCrop_name3());

        holder.crop_image_1.setImageResource(my_crop_list.getImg1());
        holder.crop_image_2.setImageResource(my_crop_list.getImg2());
        holder.crop_image_3.setImageResource(my_crop_list.getImg3());


        holder.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

       if(cc != null) {


               if (arrList.contains(my_crop_list.getCrop_name1())) {
                   holder.layout1.setBackgroundColor(Color.WHITE);
                   crops_num -= 1;
                   arrList.remove(my_crop_list.getCrop_name1());
               } else {
                   if (crops_num < 5) {
                       String colorString = "#AFCFCE";
                   holder.layout1.setBackgroundColor(Color.parseColor(colorString));
                   crops_num += 1;
                   arrList.add(my_crop_list.getCrop_name1());
                   SharedPreferences.Editor editor = sharedPreferences.edit();
                   editor.putInt("crops_num1", crops_num);
                   editor.putString("selected_color1", colorString);
                   editor.apply();

                   new Thread(new Runnable() {
                       @Override
                       public void run() {
                           SelectedCard selectedCard = new SelectedCard(my_crop_list.getCrop_name1(), my_crop_list.getImg1());
                           new InsertSelectedCardTask(database).execute(selectedCard);
                       }
                   }).start();

                   } else {
                   Toast.makeText(context, "You cannot select more than 5 crops!", Toast.LENGTH_SHORT).show();
                    }
               }
               cc.set_crops_count(crops_num);
       }



            }
        });


        holder.cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println("Hello World");
             if(cc != null) {

                    if (arrList.contains(my_crop_list.getCrop_name2())) {
                        holder.layout2.setBackgroundColor(Color.WHITE);
                        --crops_num;
                        arrList.remove(my_crop_list.getCrop_name2());
                    } else {
                        if (crops_num < 5) {
                            String colorString = "#AFCFCE";
                        holder.layout2.setBackgroundColor(Color.parseColor(colorString));
                        ++crops_num;
                        arrList.add(my_crop_list.getCrop_name2());
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt("crops_num2", crops_num);
                            editor.putString("selected_color2", colorString);
                            editor.apply();
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    SelectedCard selectedCard = new SelectedCard(my_crop_list.getCrop_name2(), my_crop_list.getImg2());
                                    new InsertSelectedCardTask(database).execute(selectedCard);
                                }
                            }).start();

                    }else {
                        Toast.makeText(context, "You cannot select more than 5 crops!", Toast.LENGTH_SHORT).show();
                       }
                    }
                    cc.set_crops_count(crops_num);
            }

            }
        });


        holder.cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

           if(cc != null) {
                    if (arrList.contains(my_crop_list.getCrop_name3())) {
                        holder.layout3.setBackgroundColor(Color.WHITE);
                        --crops_num;
                        arrList.remove(my_crop_list.getCrop_name3());
                    } else {
                        if (crops_num < 5) {
                            String colorString = "#AFCFCE";
                        holder.layout3.setBackgroundColor(Color.parseColor(colorString));
                        ++crops_num;
                        arrList.add(my_crop_list.getCrop_name3());
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putInt("crops_num3", crops_num);
                            editor.putString("selected_color3", colorString);
                            editor.apply();

                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    SelectedCard selectedCard = new SelectedCard(my_crop_list.getCrop_name3(), my_crop_list.getImg3());
                                    new InsertSelectedCardTask(database).execute(selectedCard);
                                }
                            }).start();
                        } else {
                        Toast.makeText(context, "You cannot select more than 5 crops!", Toast.LENGTH_SHORT).show();
                       }
                    }
                    cc.set_crops_count(crops_num);

              }
            }
        });


    }






    @Override
    public int getItemCount() {
        return crops_model_class.length;
    }



    public void set_crops_count(CropsCount cc){
        this.cc = cc;
    }





    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView crop_text_view1;
        TextView crop_text_view2;
        TextView crop_text_view3;


        ImageView crop_image_1;
        ImageView crop_image_2;
        ImageView crop_image_3;

        CardView cardView1;
        CardView cardView2;
        CardView cardView3;

        LinearLayout layout1;
        LinearLayout layout2;
        LinearLayout layout3;



        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            crop_text_view1 = itemView.findViewById(R.id.crop_name_1);
            crop_text_view2 = itemView.findViewById(R.id.crop_name_2);
            crop_text_view3 = itemView.findViewById(R.id.crop_name_3);


            crop_image_1 = itemView.findViewById(R.id.crop_img_1);
            crop_image_2 = itemView.findViewById(R.id.crop_img_2);
            crop_image_3 = itemView.findViewById(R.id.crop_img_3);

            cardView1 = itemView.findViewById(R.id.cardView1);
            cardView2 = itemView.findViewById(R.id.cardView2);
            cardView3 = itemView.findViewById(R.id.cardView3);


            layout1 = itemView.findViewById(R.id.l1);
            layout2 = itemView.findViewById(R.id.l2);
            layout3 = itemView.findViewById(R.id.l3);

        }
    }

}