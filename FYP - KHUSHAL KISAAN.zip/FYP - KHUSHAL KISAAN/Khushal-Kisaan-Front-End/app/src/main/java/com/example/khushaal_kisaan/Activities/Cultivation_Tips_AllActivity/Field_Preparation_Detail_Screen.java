package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Field_Preparation_Detail_Screen extends AppCompatActivity {
    ImageView back,field_preparation_readmore_image;
    TextView field_preparation_readmore_title,field_preparation_readmore_subtitle,field_preparation_readmore_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_field_preparation_detail_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        field_preparation_readmore_image.setImageResource(image);
        field_preparation_readmore_title.setText(subtitle);
        field_preparation_readmore_date.setText(date);
        field_preparation_readmore_subtitle.setText(title);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        field_preparation_readmore_image = findViewById(R.id.field_preparation_readmore_image);
        field_preparation_readmore_title = findViewById(R.id.field_preparation_readmore_title);
        field_preparation_readmore_subtitle = findViewById(R.id.field_preparation_readmore_subtitle);
        field_preparation_readmore_date = findViewById(R.id.field_preparation_readmore_date);



    }
}