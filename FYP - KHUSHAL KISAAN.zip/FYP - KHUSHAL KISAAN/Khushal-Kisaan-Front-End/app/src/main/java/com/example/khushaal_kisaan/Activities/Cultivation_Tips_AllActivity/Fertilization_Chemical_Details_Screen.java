package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Fertilization_Chemical_Details_Screen extends AppCompatActivity {
    ImageView back,fertilization_chemical_readmore_image;
    TextView fertilization_chemical_readmore_title,fertilization_chemical_readmore_subtitle,fertilization_chemical_readmore_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fertilization_chemical_details_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        fertilization_chemical_readmore_image.setImageResource(image);
        fertilization_chemical_readmore_subtitle.setText(subtitle);
        fertilization_chemical_readmore_title.setText(title);
        fertilization_chemical_readmore_date.setText(date);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        fertilization_chemical_readmore_image = findViewById(R.id.fertilization_chemical_readmore_image);
        fertilization_chemical_readmore_date = findViewById(R.id.fertilization_chemical_readmore_date);
        fertilization_chemical_readmore_title = findViewById(R.id.fertilization_chemical_readmore_title);
        fertilization_chemical_readmore_subtitle = findViewById(R.id.fertilization_chemical_readmore_subtitle);

    }
}