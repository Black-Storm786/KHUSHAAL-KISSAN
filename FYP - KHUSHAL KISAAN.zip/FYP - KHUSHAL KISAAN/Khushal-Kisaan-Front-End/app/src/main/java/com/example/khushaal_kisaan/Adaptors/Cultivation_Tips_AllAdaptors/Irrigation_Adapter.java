package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Irrigation_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Irrigation_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Irrigation_Adapter extends RecyclerView.Adapter<Irrigation_Adapter.ViewHolder> {
    Context context;
    ArrayList<Irrigation_ModelClass> irrigation_data = new ArrayList<>();

    public Irrigation_Adapter(Context context, ArrayList<Irrigation_ModelClass> irrigation_data) {
        this.context = context;
        this.irrigation_data = irrigation_data;
    }

    @NonNull
    @Override
    public Irrigation_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.irrigation_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Irrigation_Adapter.ViewHolder holder, int position) {
        holder.irrigationcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Irrigation_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",irrigation_data.get(position).getImage());
                i.putExtra("subtitle",irrigation_data.get(position).getSubtitle());
                i.putExtra("title",irrigation_data.get(position).getTitle());
                i.putExtra("date",irrigation_data.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.irrigation_image.setImageResource(irrigation_data.get(position).getImage());
        holder.irrigation_title.setText(irrigation_data.get(position).getTitle());
        holder.irrigation_subtitle.setText(irrigation_data.get(position).getSubtitle());
        holder.irrigation_date.setText(irrigation_data.get(position).getDate());
    }

    @Override
    public int getItemCount() {
        return irrigation_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout irrigationcard;
        ImageView irrigation_image;
        TextView irrigation_subtitle,irrigation_title,irrigation_date;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            irrigationcard = itemView.findViewById(R.id.irrigationcard);
            irrigation_image = itemView.findViewById(R.id.irrigation_image);
            irrigation_title = itemView.findViewById(R.id.irrigation_title);
            irrigation_subtitle = itemView.findViewById(R.id.irrigation_subtitle);
            irrigation_date = itemView.findViewById(R.id.irrigation_date);
        }
    }
}
