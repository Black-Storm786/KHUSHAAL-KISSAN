package com.example.khushaal_kisaan.Services;

import com.example.khushaal_kisaan.ModelClass.All_Community_Posts_ModelClass;
import com.example.khushaal_kisaan.ModelClass.Common_Exception_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.WeatherResponse;
import com.example.khushaal_kisaan.ModelClass.Login_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Signup_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Login_Signup_Response_POJO_Class;

import java.util.List;

import okhttp3.MultipartBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Query;

public interface Endpoints {

    // Signup API (Register Account)
    @POST("Sign-up")
    Call<Login_Signup_Response_POJO_Class> postSignupData(@Body Signup_Model_Class signup_model_class);


    // Login API (Authentication)
    @POST("Login")
    Call<Login_Signup_Response_POJO_Class> postLoginData(@Body Login_Model_Class login_model_class);

    // Token Validator
    @GET("Validate-Token")
    Call<Common_Exception_Model_Class> tokenValidator(@Query("auth_token") String auth_token);

    //User Image Uploading API
    @Multipart
    @POST("Upload-User-Image")
    Call<Common_Exception_Model_Class> uploadUserImage(@Part MultipartBody.Part image, @Query("email_or_phone") String emailOrPhone);


    // Retrieve All Community Posts
    @GET("Get-All-Community-Posts")
    Call<List<All_Community_Posts_ModelClass>> getAllCommunityData();


    @GET("weather")
    Call<WeatherResponse> getWeatherByCity(
            @Query("q") String cityName,
            @Query("appid") String apiKey
    );

    //User Image Uploading API
    @Multipart
    @POST("Upload-User-Image")
    Call<ResponseBody> uploadImage(@Part MultipartBody.Part image);


}
