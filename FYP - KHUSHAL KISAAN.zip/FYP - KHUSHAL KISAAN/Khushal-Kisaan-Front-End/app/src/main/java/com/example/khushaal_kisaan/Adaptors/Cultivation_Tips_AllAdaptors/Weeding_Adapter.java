package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Weeding_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Weeding_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Weeding_Adapter extends RecyclerView.Adapter<Weeding_Adapter.ViewHolder> {
    Context context;
    ArrayList<Weeding_ModelClass> weeding_data = new ArrayList<>();

    public Weeding_Adapter(Context context, ArrayList<Weeding_ModelClass> weeding_data) {
        this.context = context;
        this.weeding_data = weeding_data;
    }

    @NonNull
    @Override
    public Weeding_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.weeding_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Weeding_Adapter.ViewHolder holder, int position) {
        holder.weedingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Weeding_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",weeding_data.get(position).getImage());
                i.putExtra("title",weeding_data.get(position).getTitle());
                i.putExtra("subtitle",weeding_data.get(position).getSubtitle());
                i.putExtra("date",weeding_data.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.weeding_title.setText(weeding_data.get(position).getTitle());
        holder.weeding_date.setText(weeding_data.get(position).getDate());
        holder.weeding_subtitle.setText(weeding_data.get(position).getSubtitle());
        holder.weeding_image.setImageResource(weeding_data.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return weeding_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout weedingcard;
        ImageView weeding_image;
        TextView weeding_title,weeding_date,weeding_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            weedingcard = itemView.findViewById(R.id.weedingcard);
            weeding_title = itemView.findViewById(R.id.weeding_title);
            weeding_image = itemView.findViewById(R.id.weeding_image);
            weeding_subtitle = itemView.findViewById(R.id.weeding_subtitle);
            weeding_date = itemView.findViewById(R.id.weeding_date);
        }
    }
}
