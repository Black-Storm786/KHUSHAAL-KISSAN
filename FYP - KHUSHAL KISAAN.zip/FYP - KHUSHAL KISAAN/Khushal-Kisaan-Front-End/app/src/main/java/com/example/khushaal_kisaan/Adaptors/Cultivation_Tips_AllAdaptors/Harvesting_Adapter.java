package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Harvesting_Deatil_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Harvesting_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Harvesting_Adapter extends RecyclerView.Adapter<Harvesting_Adapter.ViewHolder> {
    Context context;
    ArrayList<Harvesting_ModelClass> harvesting_data = new ArrayList<>();

    public Harvesting_Adapter(Context context, ArrayList<Harvesting_ModelClass> harvesting_data) {
        this.context = context;
        this.harvesting_data = harvesting_data;
    }

    @NonNull
    @Override
    public Harvesting_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.harvesting_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Harvesting_Adapter.ViewHolder holder, int position) {
        holder.harvestingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Harvesting_Deatil_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",harvesting_data.get(position).getImage());
                i.putExtra("title",harvesting_data.get(position).getTitle());
                i.putExtra("subtitle",harvesting_data.get(position).getSubtitle());
                i.putExtra("date",harvesting_data.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.harvesting_subtitle.setText(harvesting_data.get(position).getSubtitle());
        holder.harvesting_title.setText(harvesting_data.get(position).getTitle());
        holder.harvesting_date.setText(harvesting_data.get(position).getDate());
        holder.harvesting_image.setImageResource(harvesting_data.get(position).getImage());

    }

    @Override
    public int getItemCount() {
        return harvesting_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout harvestingcard;
        ImageView harvesting_image;
        TextView harvesting_title,harvesting_subtitle,harvesting_date;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            harvestingcard = itemView.findViewById(R.id.harvestingcard);
            harvesting_image = itemView.findViewById(R.id.harvesting_image);
            harvesting_title = itemView.findViewById(R.id.harvesting_title);
            harvesting_subtitle = itemView.findViewById(R.id.harvesting_subtitle);
            harvesting_date = itemView.findViewById(R.id.harvesting_date);
        }
    }
}
