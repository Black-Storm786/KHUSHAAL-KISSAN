package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Plant_Selection_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Plant_Selection_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Plant_Selection_Screen extends AppCompatActivity {
    RecyclerView plantselection;
    ArrayList<Plant_Selection_ModelClass> plant_selection = new ArrayList<>();
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_selection);
        initialization();
        onCliCkListeners();
    }
    private void initialization() {
        back = findViewById(R.id.back);
        plantselection = findViewById(R.id.plantselection);
    }

    private void onCliCkListeners() {
        plantselection.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        Plant_Selection_ModelClass plant_selection_screen_modelClass = new Plant_Selection_ModelClass(R.drawable.plant_selection_screen_img,"Varieties for broad bean");
        Plant_Selection_ModelClass plant_selection_screen_modelClass1 = new Plant_Selection_ModelClass(R.drawable.plant_selection_img2,"Varieties for French beans");
        plant_selection.add(plant_selection_screen_modelClass);
        plant_selection.add(plant_selection_screen_modelClass1);
        Plant_Selection_Adapter plantSelectionAdapter = new Plant_Selection_Adapter(getApplicationContext(),plant_selection);
        plantselection.setAdapter(plantSelectionAdapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }
}