package com.example.khushaal_kisaan.ModelClass;

import com.google.gson.annotations.SerializedName;

public class Login_Model_Class {
    String email_or_phone;

    String password;

    String tokenExpired;


    public Login_Model_Class(String email_or_phone, String password, String tokenExpired) {
        this.email_or_phone = email_or_phone;
        this.password = password;
        this.tokenExpired = tokenExpired;
    }

    public String getEmail_or_phone() {
        return email_or_phone;
    }

    public void setEmail_or_phone(String email_or_phone) {
        this.email_or_phone = email_or_phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTokenExpired() {
        return tokenExpired;
    }

    public void setTokenExpired(String tokenExpired) {
        this.tokenExpired = tokenExpired;
    }
}
