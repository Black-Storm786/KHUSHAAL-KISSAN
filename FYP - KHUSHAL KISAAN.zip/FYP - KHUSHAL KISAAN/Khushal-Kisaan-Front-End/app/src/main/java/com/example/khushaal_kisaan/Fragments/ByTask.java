package com.example.khushaal_kisaan.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Fertilization_Chemical_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Field_Preparation_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Harvesting_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Irrigation_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Monitoring_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Plant_Selection_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Plant_Training_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Planting_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Post_Harvest_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Preventive_Measure_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Site_Selection_Screen;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Weeding_Screen;
import com.example.khushaal_kisaan.R;
import com.google.android.material.card.MaterialCardView;

public class ByTask extends Fragment {
    MaterialCardView card1, card2,card3,card4,card5,card6,card7,card8,card9,card10,card11,card12;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_by_task, container, false);
        initialization(view);
        onCLickListeners();
        return view;
    }

    private void onCLickListeners() {
        card1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Plant_Selection_Screen.class));
            }
        });
        card2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Planting_Screen.class));
            }
        });
        card3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Plant_Training_Screen.class));
            }
        });
        card4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Monitoring_Screen.class));
            }
        });
        card5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Site_Selection_Screen.class));
            }
        });
        card6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Field_Preparation_Screen.class));
            }
        });
        card7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Weeding_Screen.class));
            }
        });
        card8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Irrigation_Screen.class));
            }
        });
        card9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Fertilization_Chemical_Screen.class));
            }
        });
        card10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Preventive_Measure_Screen.class));
            }
        });
        card11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Harvesting_Screen.class));
            }
        });
        card12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getContext(), Post_Harvest_Screen.class));
            }
        });


    }

    private void initialization(View view) {
        card1 = view.findViewById(R.id.card1);
        card2 = view.findViewById(R.id.card2);
        card3 = view.findViewById(R.id.card3);
        card4 = view.findViewById(R.id.card4);
        card5 = view.findViewById(R.id.card5);
        card6 = view.findViewById(R.id.card6);
        card7 = view.findViewById(R.id.card7);
        card8 = view.findViewById(R.id.card8);
        card9 = view.findViewById(R.id.card9);
        card10 = view.findViewById(R.id.card10);
        card11 = view.findViewById(R.id.card11);
        card12 = view.findViewById(R.id.card12);
    }
}