package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.khushaal_kisaan.R;
import com.google.android.material.button.MaterialButton;

public class Plant_Selection_Detail_Screen extends AppCompatActivity {
    ImageView back,plant_selection_readmore_img;
    TextView plant_selection_readmore_subtitle,plant_selection_readmore_title;
//    MaterialButton gotit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_selection_detail_screen);
        initialization();
        onCLickListeners();
        Intent i = getIntent();
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("img",0);
        plant_selection_readmore_img.setImageResource(image);
        plant_selection_readmore_subtitle.setText(subtitle);
        plant_selection_readmore_title.setText(subtitle);
        plant_selection_readmore_img.setImageResource(image);
    }
    private void onCLickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
//        gotit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent sendIntent = new Intent();
//                sendIntent.setAction(Intent.ACTION_SEND);
//                sendIntent.setType("text/plain");
//                sendIntent.setPackage("com.whatsapp");
//                startActivity(Intent.createChooser(sendIntent, ""));
//                startActivity(sendIntent);
//            }
//        });
    }

    private void initialization() {
        back = findViewById(R.id.back);
        plant_selection_readmore_img = findViewById(R.id.plant_selection_readmore_img);
        plant_selection_readmore_subtitle = findViewById(R.id.plant_selection_readmore_subtitle);
        plant_selection_readmore_title = findViewById(R.id.plant_selection_readmore_title);
//        gotit = findViewById(R.id.gotit);
    }
}