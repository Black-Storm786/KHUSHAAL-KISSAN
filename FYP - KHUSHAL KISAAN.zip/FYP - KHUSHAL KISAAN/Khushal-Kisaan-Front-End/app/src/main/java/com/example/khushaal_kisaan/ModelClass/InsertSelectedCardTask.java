package com.example.khushaal_kisaan.ModelClass;

import android.os.AsyncTask;

import com.example.khushaal_kisaan.Database.CardDatabase;

public class InsertSelectedCardTask extends AsyncTask<SelectedCard, Void,Void> {
    private CardDatabase database;

    public InsertSelectedCardTask(CardDatabase database) {
        this.database = database;
    }

    @Override
    protected Void doInBackground(SelectedCard... selectedCards) {
        database.myDataDao().insertData(selectedCards[0]);
        return null;
    }
}
