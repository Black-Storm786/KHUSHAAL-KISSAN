package com.example.khushaal_kisaan.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.airbnb.lottie.LottieAnimationView;
import com.example.khushaal_kisaan.ModelClass.Common_Exception_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Login_Model_Class;
import com.example.khushaal_kisaan.ModelClass.Login_Signup_Response_POJO_Class;
import com.example.khushaal_kisaan.R;
import com.example.khushaal_kisaan.Retrofit.RetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONObject;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginScreen extends AppCompatActivity {
    EditText email,password;
    ImageView eye1;
    Endpoints endpoints;
    LottieAnimationView login;
    MaterialButton btn;
    LinearLayout loginparentlayout,loginsublayout2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);
        getWindow().setStatusBarColor(ContextCompat.getColor(LoginScreen.this, R.color.mainblue_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(LoginScreen.this, R.color.mainblue_color));
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        loginsublayout2 = findViewById(R.id.loginsublayout2);
        loginsublayout2.setVisibility(View.GONE);
        login = findViewById(R.id.login);
        login.setVisibility(View.GONE);
        btn = findViewById(R.id.btn);
        loginparentlayout = findViewById(R.id.loginsubparentlayout);
        eye1 = findViewById(R.id.eye1);
        endpoints = RetrofitClient.getAPIService();
        eye1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int inputType = password.getInputType();
                if (inputType == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    // Hide the password
                    password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                } else {
                    // Show the password
                    password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                }
                // Move the cursor to the end of the text
                password.setSelection(password.getText().length());
            }
        });
    }

    public void gosignup(View view) {
        startActivity(new Intent(getApplicationContext(),SignupScreen.class));
    }

    public void gotodashboard(View view) {
        String Email = email.getText().toString();
        String Password = password.getText().toString();
        if (Email.isEmpty()){
            Snackbar snackbar = Snackbar.make(view,"Please enter your email",Snackbar.LENGTH_LONG);
            snackbar.show();
        }

//        else if (!Email.contains("@gmail.com")) {
//            Snackbar snackbar = Snackbar.make(view,"Please correct your email",Snackbar.LENGTH_LONG);
//            snackbar.show();
//        }

        else if (Password.isEmpty()) {
            Snackbar snackbar = Snackbar.make(view,"Please enter your password",Snackbar.LENGTH_LONG);
            snackbar.show();
        }

        else if (Password.length()<6) {
            Snackbar snackbar = Snackbar.make(view,"password length is too short",Snackbar.LENGTH_LONG);
            snackbar.show();
        }
        else {

            try {
                login.setVisibility(View.VISIBLE);
                loginsublayout2.setVisibility(View.VISIBLE);
                loginparentlayout.setVisibility(View.GONE);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        SharedPreferences sharedPreferences = getSharedPreferences("my_token", Context.MODE_PRIVATE);
                        String auth_token = sharedPreferences.getString("auth_token","");
                        Call<Common_Exception_Model_Class> call = endpoints.tokenValidator(auth_token);
                        call.enqueue(new Callback<Common_Exception_Model_Class>() {
                            @Override
                            public void onResponse(Call<Common_Exception_Model_Class> call, Response<Common_Exception_Model_Class> response) {


                                if (response.isSuccessful()){
                                    login.setVisibility(View.GONE);
                                    loginsublayout2.setVisibility(View.GONE);

                                    System.out.println("------- I AM INSIDE RESPONSE SUCCESSFUL IN TOKEN VALIDATOR");

                                    Common_Exception_Model_Class token_validator_response = response.body();

                                    Snackbar snackbar = Snackbar.make(view,token_validator_response.getMsg(),Snackbar.LENGTH_LONG);
                                    snackbar.show();
                                    authenticate_User(Email, Password,token_validator_response.getMsg(), view );
                                }
                                else{
                                    try {
                                        login.setVisibility(View.GONE);
                                        assert response.errorBody() != null;
                                        String errorBody = response.errorBody().string();
                                        JSONObject errorObject = new JSONObject(errorBody);
                                        String errorMsg = errorObject.getString("msg");
                                        System.out.println("------- I AM INSIDE ELSE IN TOKEN VALIDATOR: VALUE: => "+errorMsg);
                                        authenticate_User(Email, Password,errorMsg, view );
                                        Snackbar snackbar = Snackbar.make(view,"Auth Token Updated!",Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }
                                    catch (Exception e){
                                        Snackbar snackbar = Snackbar.make(view,"An Unknown Error Occurred! CAUSED BY: "+e.getMessage(),Snackbar.LENGTH_LONG);
                                        snackbar.show();
                                    }

                                }

                            }

                            @Override
                            public void onFailure(Call<Common_Exception_Model_Class> call, Throwable t) {
                                Snackbar snackbar = Snackbar.make(view,"An Unknown Error Occurred! CAUSED BY: "+t.getMessage(),Snackbar.LENGTH_LONG);
                                snackbar.show();
                            }
                        });
                    }
                },4000);



            }
            catch (Exception e){
                Snackbar snackbar = Snackbar.make(view,"An Unknown Error Occurred! CAUSED BY: "+e.getMessage(),Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        }

    }



    // Validate User
    public void authenticate_User(String email_or_phone,String password,String tokenExpired, View view){

        Login_Model_Class  login_model_class = new Login_Model_Class(email_or_phone, password, tokenExpired);

        Call<Login_Signup_Response_POJO_Class> call = endpoints.postLoginData(login_model_class);
        call.enqueue(new Callback<Login_Signup_Response_POJO_Class>() {
            @Override
            public void onResponse(Call<Login_Signup_Response_POJO_Class> call, Response<Login_Signup_Response_POJO_Class> response) {
                if (response.isSuccessful()){

                    Login_Signup_Response_POJO_Class login_auth_api_response = response.body();

                    System.out.println("the auth token is : "+login_auth_api_response.getAuth_token());

                    if(login_auth_api_response.getAuth_token().length() !=0){
                        SharedPreferences sharedPreferences = getSharedPreferences("my_token", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("auth_token", login_auth_api_response.getAuth_token());
                        editor.putString("email_or_phone",email_or_phone);
                        editor.apply();
                        System.out.println("xxxxxxxxxxxxxxxxxxxxxxx   INSIDE TOKEN UPDATION!");
                    }
                    Snackbar snackbar = Snackbar.make(view,login_auth_api_response.getMsg(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                    startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    finish();
                }
                else {
                    Snackbar snackbar = Snackbar.make(view,"InValid Credentials",Snackbar.LENGTH_LONG);
                    snackbar.show();
                    loginparentlayout.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<Login_Signup_Response_POJO_Class> call, Throwable t) {
                Snackbar snackbar = Snackbar.make(view,"An Unknown Error Occurred! CAUSED BY: "+t.getMessage(),Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        });
    }






}