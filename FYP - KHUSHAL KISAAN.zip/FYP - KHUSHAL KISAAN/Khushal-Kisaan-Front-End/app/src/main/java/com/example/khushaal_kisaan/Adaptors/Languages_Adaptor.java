package com.example.khushaal_kisaan.Adaptors;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.ModelClasses.Languages_Model_Class;
import com.example.khushaal_kisaan.Interfaces.LocaleListener;
import com.example.khushaal_kisaan.R;

public class Languages_Adaptor extends RecyclerView.Adapter<Languages_Adaptor.ViewHolder>{

    Languages_Model_Class[] lang_model_class;
    Context context;
    private LocaleListener mListener;


    public Languages_Adaptor(Languages_Model_Class[] lang_model_class, Context context) {
       this.lang_model_class = lang_model_class;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());

        View view = layoutInflater.inflate(R.layout.language_item_card_view,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        final Languages_Model_Class my_lang_list = lang_model_class[position];
        holder.language_text_view1.setText(my_lang_list.getLanguage_name1());
        holder.language_text_view2.setText(my_lang_list.getLanguage_name2());
        holder.language_text_view3.setText(my_lang_list.getLanguage_name3());

        holder.img1.setImageResource(my_lang_list.getAnim1());
        holder.img2.setImageResource(my_lang_list.getAnim2());
        holder.img3.setImageResource(my_lang_list.getAnim3());


        holder.cardView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (my_lang_list.getLanguage_name1().trim().equals("اردو")){
                    if (mListener !=null){
                        mListener.setLocale("ur");
                        //Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name1().trim()+" Language", Toast.LENGTH_SHORT).show();
//                        holder.layout1.setBackgroundColor(Color.parseColor("#AFCFCE"));
                    }
                }

                else if (my_lang_list.getLanguage_name1().trim().equals("پنجابی")){
                    if (mListener !=null){
                        mListener.setLocale("ar");
                        //Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name1().trim()+" Language", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });


        holder.cardView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (my_lang_list.getLanguage_name2().trim().equals("پشتو")){
                    if (mListener !=null){
                        mListener.setLocale("ps");
                      //  Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name1().trim()+" Language", Toast.LENGTH_SHORT).show();

                    }
                }

                else if (my_lang_list.getLanguage_name2().trim().equals("بلوچی")){
                    if (mListener !=null){
                        mListener.setLocale("bal");
                       // Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name2().trim()+" Language", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });



        holder.cardView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (my_lang_list.getLanguage_name3().trim().equals("سندھی")){
                    if (mListener !=null){
                        mListener.setLocale("sd");
                       // Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name3().trim()+" Language", Toast.LENGTH_SHORT).show();
                    }
                }

                else if (my_lang_list.getLanguage_name3().trim().equals("English")){
                    if (mListener !=null){
                        mListener.setLocale("en");
                        //Toast.makeText(context, "You Selected "+my_lang_list.getLanguage_name3().trim()+" Language", Toast.LENGTH_SHORT).show();

                    }
                }
            }
        });



    }



    @Override
    public int getItemCount()
    {
        return lang_model_class.length;
    }



    public void setLocaleListener(LocaleListener listener) {
        mListener = listener;
    }



    //Creating View Holder...!


    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView language_text_view1;
        TextView language_text_view2;
        TextView language_text_view3;

        CardView cardView1;
        CardView cardView2;
        CardView cardView3;


        ImageView img1;
        ImageView img2;
        ImageView img3;




        public ViewHolder(@NonNull View itemView) {
            super(itemView);


            language_text_view1 = itemView.findViewById(R.id.lang_name_1);
            language_text_view2 = itemView.findViewById(R.id.lang_name_2);
            language_text_view3 = itemView.findViewById(R.id.lang_name_3);



            img1 = itemView.findViewById(R.id.anim1);
            img2 = itemView.findViewById(R.id.anim2);
            img3 = itemView.findViewById(R.id.anim3);



            cardView1 = itemView.findViewById(R.id.cardView1);
            cardView2 = itemView.findViewById(R.id.cardView2);
            cardView3 = itemView.findViewById(R.id.cardView3);







        }
    }


}
