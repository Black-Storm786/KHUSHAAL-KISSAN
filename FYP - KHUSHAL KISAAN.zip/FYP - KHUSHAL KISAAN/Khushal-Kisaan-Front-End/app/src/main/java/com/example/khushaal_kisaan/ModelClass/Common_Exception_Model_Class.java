package com.example.khushaal_kisaan.ModelClass;

import com.google.gson.annotations.SerializedName;

public class Common_Exception_Model_Class {
    @SerializedName("status")
    String status;

    @SerializedName("msg")
    String msg;

    public Common_Exception_Model_Class(String status, String msg) {
        this.status = status;
        this.msg = msg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
