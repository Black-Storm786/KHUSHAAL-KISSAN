package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Post_Harvest_ModelClass {
    Integer image;
    String subtitle;

    public Post_Harvest_ModelClass(Integer image, String subtitle) {
        this.image = image;
        this.subtitle = subtitle;
    }

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
