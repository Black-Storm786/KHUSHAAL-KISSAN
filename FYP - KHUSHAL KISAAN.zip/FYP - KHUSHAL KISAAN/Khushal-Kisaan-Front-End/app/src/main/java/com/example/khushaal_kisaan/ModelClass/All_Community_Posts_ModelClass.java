package com.example.khushaal_kisaan.ModelClass;

public class All_Community_Posts_ModelClass {
    String post_id;
    String user_image;
    String user_email_or_phone;
    String image_one;
    String image_two;
    String image_three;
    String post_title;
    String post_description;
    String time_stamp;

    public All_Community_Posts_ModelClass(String post_id, String user_image, String user_email_or_phone, String image_one, String image_two, String image_three, String post_title, String post_description, String time_stamp) {
        this.post_id = post_id;
        this.user_image = user_image;
        this.user_email_or_phone = user_email_or_phone;
        this.image_one = image_one;
        this.image_two = image_two;
        this.image_three = image_three;
        this.post_title = post_title;
        this.post_description = post_description;
        this.time_stamp = time_stamp;
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getUser_image() {
        return user_image;
    }

    public void setUser_image(String user_image) {
        this.user_image = user_image;
    }

    public String getUser_email_or_phone() {
        return user_email_or_phone;
    }

    public void setUser_email_or_phone(String user_email_or_phone) {
        this.user_email_or_phone = user_email_or_phone;
    }

    public String getImage_one() {
        return image_one;
    }

    public void setImage_one(String image_one) {
        this.image_one = image_one;
    }

    public String getImage_two() {
        return image_two;
    }

    public void setImage_two(String image_two) {
        this.image_two = image_two;
    }

    public String getImage_three() {
        return image_three;
    }

    public void setImage_three(String image_three) {
        this.image_three = image_three;
    }

    public String getPost_title() {
        return post_title;
    }

    public void setPost_title(String post_title) {
        this.post_title = post_title;
    }

    public String getPost_description() {
        return post_description;
    }

    public void setPost_description(String post_description) {
        this.post_description = post_description;
    }

    public String getTime_stamp() {
        return time_stamp;
    }

    public void setTime_stamp(String time_stamp) {
        this.time_stamp = time_stamp;
    }
}
