package com.example.khushaal_kisaan.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.khushaal_kisaan.R;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class AskCommunity_Screen extends AppCompatActivity {
    CardView gallery,camera;
    ImageButton icon;
    ImageView image;
    EditText edittext1,edittext2;
    TextView txt1,txt2;
    ImageSlider slider;
    private static final int GALLERY_REQUEST_CODE = 123;
    private static final int CAMERA_REQUEST_CODE = 456;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 789;
    private List<SlideModel> imageList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ask_community_screen);
        edittext1 = findViewById(R.id.edittext1);
        txt1 = findViewById(R.id.txt1);
        edittext2 = findViewById(R.id.edittext2);
        txt2 = findViewById(R.id.txt2);
        slider = findViewById(R.id.slider);
        imageList = new ArrayList<>();
        slider.setVisibility(View.GONE);
//        imageList.add(new SlideModel("", ScaleTypes.FIT));

        // Set the adapter for the image slider
        slider.setImageList(imageList, ScaleTypes.FIT);
//        image = findViewById(R.id.image);
        icon = findViewById(R.id.icon);
        icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Hide the ImageView
                if (!imageList.isEmpty()) {
                    imageList.remove(imageList.size() - 1);
                }

                // Update the image slider with the updated imageList
                slider.setImageList(imageList, ScaleTypes.FIT);

                // Hide the slider and remove button if the imageList is empty
                if (imageList.isEmpty()) {
                    slider.setVisibility(View.GONE);
                    icon.setVisibility(View.GONE);
                }
            }
        });
        camera = findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCamera();
            }
        });
//        image.setVisibility(View.GONE);
        icon.setVisibility(View.GONE);
        edittext1.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                int length = charSequence.length();
                txt1.setText(length + " / 200 characters");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        edittext2.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                int length = charSequence.length();
                txt2.setText(length + " / 200 characters");
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
        gallery = findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
            }
        });

    }

    private void openCamera() {
        if (checkCameraPermission()) {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        } else {
            requestCameraPermission();
        }
    }
    private boolean checkCameraPermission() {
        int cameraPermission = checkSelfPermission(android.Manifest.permission.CAMERA);
        return cameraPermission == PackageManager.PERMISSION_GRANTED;
    }
    private void requestCameraPermission() {
        requestPermissions(new String[]{android.Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            Uri selectedImageUri = data.getData();
//            image.setVisibility(View.VISIBLE);
            imageList.add(new SlideModel(selectedImageUri.toString(),ScaleTypes.FIT));
             slider.setImageList(imageList,ScaleTypes.FIT);
             slider.setVisibility(View.VISIBLE);
            icon.setVisibility(View.VISIBLE);

            // Set visibility of image to visible
//            image.setImageURI(selectedImageUri);
        }
        else if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data!=null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            Uri photoUri = getImageUri(photo);
            imageList.add(new SlideModel(photoUri.toString(), ScaleTypes.FIT));
            slider.setImageList(imageList, ScaleTypes.FIT);
//            image.setVisibility(View.VISIBLE);
            slider.setVisibility(View.VISIBLE);
            icon.setVisibility(View.VISIBLE);
            // Set visibility of image to visible
//            image.setImageBitmap(photo);
        }
    }

    private Uri getImageUri(Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "Title", null);
        return Uri.parse(path);
    }

    public void goBack(View view) {
        onBackPressed();
    }
}
