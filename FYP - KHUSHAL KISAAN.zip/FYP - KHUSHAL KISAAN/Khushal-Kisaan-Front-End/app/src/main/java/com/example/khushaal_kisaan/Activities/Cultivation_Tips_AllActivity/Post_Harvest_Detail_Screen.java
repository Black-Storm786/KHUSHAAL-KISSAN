package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Post_Harvest_Detail_Screen extends AppCompatActivity {
    ImageView back,post_harvest_readmore_image;
    TextView post_harvest_readmore_subtitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_harvest_detail_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        post_harvest_readmore_image.setImageResource(image);
        post_harvest_readmore_subtitle.setText(subtitle);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        post_harvest_readmore_image = findViewById(R.id.post_harvest_readmore_image);
        post_harvest_readmore_subtitle = findViewById(R.id.post_harvest_readmore_subtitle);

    }
}