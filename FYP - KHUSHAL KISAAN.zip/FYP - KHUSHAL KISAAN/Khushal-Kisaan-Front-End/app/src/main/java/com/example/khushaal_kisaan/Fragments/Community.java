package com.example.khushaal_kisaan.Fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.khushaal_kisaan.Activities.AskCommunity_Screen;
import com.example.khushaal_kisaan.Adaptors.Community_Adapter;
import com.example.khushaal_kisaan.Database.CardDatabase;
import com.example.khushaal_kisaan.ModelClass.All_Community_Posts_ModelClass;
import com.example.khushaal_kisaan.ModelClass.Community_ModelClass;
import com.example.khushaal_kisaan.ModelClass.SelectedCard;
import com.example.khushaal_kisaan.R;
import com.example.khushaal_kisaan.Retrofit.RetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Community extends Fragment {


    private FloatingActionButton fab;



    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private Community_Adapter community_adapter;
    public Community() {
        // Required empty public constructor
    }
    RecyclerView communityrecycle;
    ExtendedFloatingActionButton btn;
    private ArrayList<SlideModel> slideModels = new ArrayList<>();
     ArrayList<All_Community_Posts_ModelClass> community_modelClasses = new ArrayList<>();
    Endpoints endpoints;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_community, container, false);
        communityrecycle = view.findViewById(R.id.communityrecycle);
        btn = view.findViewById(R.id.btn);
        endpoints = RetrofitClient.getAPIService();
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AskCommunity_Screen.class));
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false);
        communityrecycle.setLayoutManager(linearLayoutManager);
        community_adapter = new Community_Adapter(community_modelClasses,getContext());
        communityrecycle.setAdapter(community_adapter);

        try {
            Call<List<All_Community_Posts_ModelClass>> call = endpoints.getAllCommunityData();
            call.enqueue(new Callback<List<All_Community_Posts_ModelClass>>() {
                @Override
                public void onResponse(Call<List<All_Community_Posts_ModelClass>> call, Response<List<All_Community_Posts_ModelClass>> response) {
                     if (response.isSuccessful()){
                       ArrayList<All_Community_Posts_ModelClass> data = (ArrayList<All_Community_Posts_ModelClass>) response.body();
                         community_modelClasses.addAll(data);
                         community_adapter.notifyDataSetChanged();
                         System.out.println(community_modelClasses);
                     }
                }

                @Override
                public void onFailure(Call<List<All_Community_Posts_ModelClass>> call, Throwable t) {

                }
            });
        }
        catch (Exception e){

        }
        return view;
    }



}

