package com.example.khushaal_kisaan.ModelClass;

import com.google.gson.annotations.SerializedName;

public class Signup_Model_Class {

//    @SerializedName("username")
    String username;

//    @SerializedName("email_or_phone")
    String email_or_phone;

//    @SerializedName("password")
    String password;

    public Signup_Model_Class(String username, String email_or_phone, String password) {
        this.username = username;
        this.email_or_phone = email_or_phone;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail_or_phone() {
        return email_or_phone;
    }

    public void setEmail_or_phone(String email_or_phone) {
        this.email_or_phone = email_or_phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
