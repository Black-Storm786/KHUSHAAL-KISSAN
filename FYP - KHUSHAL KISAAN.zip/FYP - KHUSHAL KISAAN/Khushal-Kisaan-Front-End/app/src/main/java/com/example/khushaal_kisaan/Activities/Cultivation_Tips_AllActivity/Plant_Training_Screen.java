package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Plant_Training_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Plant_Training_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Plant_Training_Screen extends AppCompatActivity {
    RecyclerView planttraining;
    ArrayList<Plant_Training_ModelClass> plant_training_data = new ArrayList<>();
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_plant_training);
        initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        planttraining.setLayoutManager(linearLayoutManager);
        Plant_Training_ModelClass plant_training_screen_modelClass = new  Plant_Training_ModelClass(R.drawable.planting_screen_image3,"Supporting Climbing French beans");
        plant_training_data.add(plant_training_screen_modelClass);
        Plant_Training_Adapter plant_training_adapter = new Plant_Training_Adapter(getApplicationContext(),plant_training_data);
        planttraining.setAdapter(plant_training_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void initialization() {
        planttraining = findViewById(R.id.planttraining);
        back = findViewById(R.id.back);

    }
}