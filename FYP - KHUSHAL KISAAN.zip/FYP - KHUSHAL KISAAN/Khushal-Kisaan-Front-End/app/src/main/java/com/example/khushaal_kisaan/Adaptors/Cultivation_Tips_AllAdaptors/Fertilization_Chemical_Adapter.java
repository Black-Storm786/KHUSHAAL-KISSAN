package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Fertilization_Chemical_Details_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Fertilization_Chemical_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Fertilization_Chemical_Adapter extends RecyclerView.Adapter<Fertilization_Chemical_Adapter.ViewHolder> {
    Context context;
    ArrayList<Fertilization_Chemical_ModelClass> fertilization_date = new ArrayList<>();

    public Fertilization_Chemical_Adapter(Context context, ArrayList<Fertilization_Chemical_ModelClass> fertilization_date) {
        this.context = context;
        this.fertilization_date = fertilization_date;
    }

    @NonNull
    @Override
    public Fertilization_Chemical_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.fertilization_chemical_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Fertilization_Chemical_Adapter.ViewHolder holder, int position) {
        holder.fertilizationchemicalcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Fertilization_Chemical_Details_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",fertilization_date.get(position).getImage());
                i.putExtra("title",fertilization_date.get(position).getTitle());
                i.putExtra("subtitle",fertilization_date.get(position).getSubtitle());
                i.putExtra("date",fertilization_date.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.fertilization_chemical_date.setText(fertilization_date.get(position).getDate());
        holder.fertilization_chemical_title.setText(fertilization_date.get(position).getTitle());
        holder.fertilization_chemical_subtitle.setText(fertilization_date.get(position).getSubtitle());
        holder.fertilization_chemical_image.setImageResource(fertilization_date.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return fertilization_date.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout fertilizationchemicalcard;
        ImageView fertilization_chemical_image;
        TextView fertilization_chemical_title,fertilization_chemical_subtitle,fertilization_chemical_date;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fertilizationchemicalcard = itemView.findViewById(R.id.fertilizationchemicalcard);
            fertilization_chemical_image = itemView.findViewById(R.id.fertilization_chemical_image);
            fertilization_chemical_title = itemView.findViewById(R.id.fertilization_chemical_title);
            fertilization_chemical_subtitle = itemView.findViewById(R.id.fertilization_chemical_subtitle);
            fertilization_chemical_date = itemView.findViewById(R.id.fertilization_chemical_date);
        }
    }
}
