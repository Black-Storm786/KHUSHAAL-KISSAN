package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Plant_Selection_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Plant_Selection_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Plant_Selection_Adapter extends RecyclerView.Adapter<Plant_Selection_Adapter.ViewHolder> {

    Context context;
    ArrayList<Plant_Selection_ModelClass> plant_selection = new ArrayList<>();

    public Plant_Selection_Adapter(Context context, ArrayList<Plant_Selection_ModelClass> plant_selection) {
        this.context = context;
        this.plant_selection = plant_selection;
    }

    @NonNull
    @Override
    public Plant_Selection_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.plant_selection_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Plant_Selection_Adapter.ViewHolder holder, int position) {
        holder.plantselectioncard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Plant_Selection_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("subtitle",plant_selection.get(position).getPlant_selection_subtitle());
                i.putExtra("img",plant_selection.get(position).getPlant_selection_img());
                context.startActivity(i);
            }
        });
        holder.plant_selection_img.setImageResource(plant_selection.get(position).getPlant_selection_img());
        holder.plant_selection_subtitle.setText(plant_selection.get(position).getPlant_selection_subtitle());

    }

    @Override
    public int getItemCount() {
        return plant_selection.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout plantselectioncard;
        ImageView plant_selection_img;
        TextView plant_selection_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            plantselectioncard = itemView.findViewById(R.id.plantselectioncard);
            plant_selection_img = itemView.findViewById(R.id.plant_selection_img);
            plant_selection_subtitle = itemView.findViewById(R.id.plant_selection_subtitle);
        }
    }
}
