package com.example.khushaal_kisaan.Activities;


import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Adaptors.Weather_ForeCasting_Adapter;
import com.example.khushaal_kisaan.CommonFunctions.HorizontalSpaceItemDecoration;
import com.example.khushaal_kisaan.R;


public class Weather_Forecasting extends AppCompatActivity {

    private ImageView imageView;
    private RecyclerView recycle;

    private Weather_ForeCasting_Adapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_forecasting);
        getWindow().setStatusBarColor(ContextCompat.getColor(Weather_Forecasting.this, R.color.mainblue_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(Weather_Forecasting.this, R.color.mainblue_color));





        getCurrentLocation();

    }



    private void getCurrentLocation() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }

        Location location = locationManager.getLastKnownLocation(locationManager.getBestProvider(criteria, false));
        if (location != null) {
            double lat = location.getLatitude();
            double lon = location.getLongitude();

            System.out.println("LONG: "+lon+" LAT: "+lat);
        }
    }


    public void goBack(View view){
        onBackPressed();
    }


//================== BELOW IS THE CODE FOR SETTING HORIZONTAL RECYCLER VIEW ==================

    //        recycle = findViewById(R.id.all_day_weather_recyclerview);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
//
//        int spacingInPixels = getResources().getDimensionPixelSize(R.dimen.activity_horizontal_margin);
//        recycle.addItemDecoration(new HorizontalSpaceItemDecoration(spacingInPixels));
//
//        adapter = new Weather_ForeCasting_Adapter(getApplicationContext());
//        recycle.setLayoutManager(layoutManager);
//        recycle.setAdapter(adapter);

//        imageView = findViewById(R.id.weather_incoming_icon);
//
//        String url = "http://openweathermap.org/img/w/04d.png";
//
//        Glide.with(getApplicationContext())
//        .load(url)
//        .into(imageView);




}