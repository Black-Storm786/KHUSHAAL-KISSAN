package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Site_Selection_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Site_Slection_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Site_Selection_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView siteselection;
    ArrayList<Site_Slection_ModelClass> site_selection_data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site_selection_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        siteselection.setLayoutManager(linearLayoutManager);
        Site_Slection_ModelClass site_selection_screen_modelClass1 = new Site_Slection_ModelClass(R.drawable.plant_selection_img2,"3 weeks before seeding","13 - 20 MAR","Conditions for bean cultivation");
        Site_Slection_ModelClass site_selection_screen_modelClass2 = new Site_Slection_ModelClass(R.drawable.plant_selection_screen_img,"week 13","26 JUN - 3 JUL","Rotate crops properly");
        site_selection_data.add(site_selection_screen_modelClass1);
        site_selection_data.add(site_selection_screen_modelClass2);

        Site_Selection_Adapter site_slection_adapter = new Site_Selection_Adapter(getApplicationContext(),site_selection_data);
        siteselection.setAdapter(site_slection_adapter);
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        siteselection = findViewById(R.id.siteselection);
    }
}