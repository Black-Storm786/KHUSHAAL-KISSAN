package com.example.khushaal_kisaan.Interfaces;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.khushaal_kisaan.ModelClass.SelectedCard;

import java.util.List;

@Dao
public interface SelectedCardDao {
    @Insert
    void insertData(SelectedCard data);

    @Query("select * from crops")
    List<SelectedCard> getAllSelectedCards();

    @Delete
    void deletetransaction(SelectedCard selectedCard);

}
