package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Fertilization_Chemical_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Fertilization_Chemical_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Fertilization_Chemical_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView fertilizationchemical;
    ArrayList<Fertilization_Chemical_ModelClass> fertilization_date = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fertilization_chemical_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        fertilizationchemical.setLayoutManager(linearLayoutManager);
        Fertilization_Chemical_ModelClass fertilizationChemical_screen_modelClass1 = new Fertilization_Chemical_ModelClass(R.drawable.planting_screen_image3,"1 week before seeding","Basal fertilization of beans","27 MAR - 3 APR");
        Fertilization_Chemical_ModelClass fertilizationChemical_screen_modelClass2 = new Fertilization_Chemical_ModelClass(R.drawable.planting_screen_image2,"Week 4","Micronutrient application for extra support","24 APR - 1 MAY");
        Fertilization_Chemical_ModelClass fertilizationChemical_screen_modelClass3 = new Fertilization_Chemical_ModelClass(R.drawable.planting_screen_image1,"Week 4","French bean split fertilizer","24 APR - 1 MAY");
        fertilization_date.add(fertilizationChemical_screen_modelClass1);
        fertilization_date.add(fertilizationChemical_screen_modelClass2);
        fertilization_date.add(fertilizationChemical_screen_modelClass3);
        Fertilization_Chemical_Adapter fertilization_chemical_screen_adapter = new Fertilization_Chemical_Adapter(getApplicationContext(),fertilization_date);
        fertilizationchemical.setAdapter(fertilization_chemical_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        fertilizationchemical = findViewById(R.id.fertilizationchemical);

    }
}