package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Site_Slection_ModelClass {
    int image;
    String title;
    String date;
    String subtitle;

    public Site_Slection_ModelClass(int image, String title, String date, String subtitle) {
        this.image = image;
        this.title = title;
        this.date = date;
        this.subtitle = subtitle;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
