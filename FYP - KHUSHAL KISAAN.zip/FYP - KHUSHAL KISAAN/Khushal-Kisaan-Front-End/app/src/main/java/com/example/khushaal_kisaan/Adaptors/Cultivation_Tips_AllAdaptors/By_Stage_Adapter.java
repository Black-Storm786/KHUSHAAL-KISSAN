package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.By_Stage_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class By_Stage_Adapter extends RecyclerView.Adapter<By_Stage_Adapter.ViewHolder> {
    Context context;
    ArrayList<By_Stage_ModelClass> preventive_data = new ArrayList<>();

    public By_Stage_Adapter(Context context, ArrayList<By_Stage_ModelClass> preventive_data) {
        this.context = context;
        this.preventive_data = preventive_data;
    }

    @NonNull
    @Override
    public By_Stage_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.by_stage_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull By_Stage_Adapter.ViewHolder holder, int position) {
//        holder.preventivemeasurecard.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent i = new Intent(context, PreventiveMeasure_ReadMore_Screen.class);
//                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                i.putExtra("image",preventive_data.get(position).getImage());
//                i.putExtra("title",preventive_data.get(position).getTitle());
//                i.putExtra("subtitle",preventive_data.get(position).getSubtitle());
//                i.putExtra("date",preventive_data.get(position).getDate());
//                context.startActivity(i);
//            }
//        });
        holder.preventive_measure_subtitle.setText(preventive_data.get(position).getSubtitle());
        holder.preventive_measure_title.setText(preventive_data.get(position).getTitle());
        holder.preventive_measure_date.setText(preventive_data.get(position).getDate());
        holder.preventive_measure_image.setImageResource(preventive_data.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return preventive_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout preventivemeasurecard;
        ImageView preventive_measure_image;
        TextView preventive_measure_date,preventive_measure_title,preventive_measure_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            preventivemeasurecard = itemView.findViewById(R.id.preventivemeasurecard);
            preventive_measure_image = itemView.findViewById(R.id.preventive_measure_image);
            preventive_measure_date = itemView.findViewById(R.id.preventive_measure_date);
            preventive_measure_title = itemView.findViewById(R.id.preventive_measure_title);
            preventive_measure_subtitle = itemView.findViewById(R.id.preventive_measure_subtitle);
        }
    }
}
