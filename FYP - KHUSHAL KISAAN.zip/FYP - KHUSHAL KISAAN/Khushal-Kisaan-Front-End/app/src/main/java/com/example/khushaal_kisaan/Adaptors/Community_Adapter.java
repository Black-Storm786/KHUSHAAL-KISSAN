package com.example.khushaal_kisaan.Adaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Irrigation_Detail_Screen;
import com.example.khushaal_kisaan.Community_Details_Screen;
import com.example.khushaal_kisaan.ModelClass.All_Community_Posts_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Community_Adapter extends RecyclerView.Adapter<Community_Adapter.ViewHolder> {
    ArrayList<All_Community_Posts_ModelClass> community_modelClasses = new ArrayList<>();
    Context context;

    public Community_Adapter(ArrayList<All_Community_Posts_ModelClass> community_modelClasses, Context context) {
        this.community_modelClasses = community_modelClasses;
        this.context = context;
    }

    @NonNull
    @Override
    public Community_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.community_card, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Community_Adapter.ViewHolder holder, int position) {

        All_Community_Posts_ModelClass item = community_modelClasses.get(position);
        ArrayList<SlideModel> slideModels = new ArrayList<>(); // Create a new list for each item

        if (item.getImage_one() != null) {
            slideModels.add(new SlideModel(item.getImage_one(), ScaleTypes.FIT));
        }
        if (item.getImage_two() != null) {
            slideModels.add(new SlideModel(item.getImage_two(), ScaleTypes.FIT));
        }
        if (item.getImage_three() != null) {
            slideModels.add(new SlideModel(item.getImage_three(), ScaleTypes.FIT));
        }

        holder.communityimageslider.setImageList(slideModels);
        holder.title.setText(item.getPost_title());
        holder.description.setText(item.getPost_description());
       if (item.getUser_image()!=null){
           Glide.with(context)
                   .load(item.getUser_image())
                   .into(holder.cummunityimg);
       }

       holder.communitycard.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent i = new Intent(context,Community_Details_Screen.class);
               i.putExtra("id",item.getPost_id());
               context.startActivity(i);
           }
       });



    }

    @Override
    public int getItemCount() {
        return community_modelClasses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout communitycard;
        ImageView cummunityimg;
        ImageSlider communityimageslider;
        TextView title, description;
        CardView slidercardview;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            communityimageslider = itemView.findViewById(R.id.communityimageslider);
            title = itemView.findViewById(R.id.title);
            description = itemView.findViewById(R.id.description);
            communitycard = itemView.findViewById(R.id.communitycard);
            slidercardview = itemView.findViewById(R.id.slidercardview);
            cummunityimg = itemView.findViewById(R.id.cummunityimg);
        }
    }
}
