package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Field_Preparation_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Field_Preparation_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Field_Preparation_Adapter extends RecyclerView.Adapter<Field_Preparation_Adapter.ViewHolder> {
    Context context;
    ArrayList<Field_Preparation_ModelClass> field_preparation_data = new ArrayList<>();

    public Field_Preparation_Adapter(Context context, ArrayList<Field_Preparation_ModelClass> field_preparation_data) {
        this.context = context;
        this.field_preparation_data = field_preparation_data;
    }

    @NonNull
    @Override
    public Field_Preparation_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.field_preparation_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Field_Preparation_Adapter.ViewHolder holder, int position) {
        holder.fieldpreparationcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Field_Preparation_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",field_preparation_data.get(position).getImage());
                i.putExtra("title",field_preparation_data.get(position).getTitle());
                i.putExtra("subtitle",field_preparation_data.get(position).getSubtitle());
                i.putExtra("date",field_preparation_data.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.field_preration_image.setImageResource(field_preparation_data.get(position).getImage());
        holder.field_preration_subtitle.setText(field_preparation_data.get(position).getSubtitle());
        holder.field_preration_date.setText(field_preparation_data.get(position).getDate());
        holder.field_preration_title.setText(field_preparation_data.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return field_preparation_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout fieldpreparationcard;
        ImageView field_preration_image;
        TextView field_preration_title,field_preration_date,field_preration_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            fieldpreparationcard = itemView.findViewById(R.id.fieldpreparationcard);
            field_preration_image = itemView.findViewById(R.id.field_preration_image);
            field_preration_title = itemView.findViewById(R.id.field_preration_title);
            field_preration_date = itemView.findViewById(R.id.field_preration_date);
            field_preration_subtitle = itemView.findViewById(R.id.field_preration_subtitle);
        }
    }
}
