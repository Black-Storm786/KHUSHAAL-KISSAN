package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Weeding_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Weeding_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Weeding_Screen extends AppCompatActivity {
    ImageView back;
    ArrayList<Weeding_ModelClass> weeding_data = new ArrayList<>();
    RecyclerView weeding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weeding_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        weeding.setLayoutManager(linearLayoutManager);
        Weeding_ModelClass weeding_screen_modelClass1 = new Weeding_ModelClass(R.drawable.plant_selection_screen_img,"Week 1","Plan a pre-emergence weeding after sowing","3 - 10 APR - CURRENT");
        weeding_data.add(weeding_screen_modelClass1);
        Weeding_Adapter weedingScreen_adapter = new Weeding_Adapter(getApplicationContext(),weeding_data);
        weeding.setAdapter(weedingScreen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        weeding = findViewById(R.id.weeding);

    }
}