package com.example.khushaal_kisaan.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.khushaal_kisaan.Fragments.Community;
import com.example.khushaal_kisaan.Fragments.Home;
import com.example.khushaal_kisaan.Fragments.Profile;
import com.example.khushaal_kisaan.ModelClass.Common_Exception_Model_Class;
import com.example.khushaal_kisaan.R;
import com.example.khushaal_kisaan.Retrofit.RetrofitClient;
import com.example.khushaal_kisaan.Services.Endpoints;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.ismaeldivita.chipnavigation.ChipNavigationBar;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardActivity extends AppCompatActivity {


//    private LottieAnimationView leftside_menu;
//   // private LottieAnimationView rightside_menu;
//
//    private NavigationView nav_view;
//    private DrawerLayout drawerLayout;
//    private Toolbar toolbar;

    private FrameLayout framelayout;
    private ChipNavigationBar bottomNavigationView;
    DrawerLayout mwrappering;
    ImageView leftsidemenu,profileimg;
    CardView edit;
    NavigationView navigationview;
    private static final int GALLERY_REQUEST_CODE = 123;
    Endpoints endpoints;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        endpoints = RetrofitClient.getAPIService();
        getWindow().setStatusBarColor(ContextCompat.getColor(DashboardActivity.this, R.color.mainblue_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(DashboardActivity.this, R.color.mainblue_color));
        mwrappering = findViewById(R.id.mwrappering);
        navigationview = findViewById(R.id.navigationview);
        edit = navigationview.getHeaderView(0).findViewById(R.id.edit);
        profileimg = navigationview.getHeaderView(0).findViewById(R.id.profileimg);
        edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE);
//                openProfileFragment();
            }
        });
        leftsidemenu = findViewById(R.id.leftsidemenu);
        leftsidemenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mwrappering.isOpen()){
                    mwrappering.close();
                }
                else {
                    mwrappering.openDrawer(GravityCompat.START);
                }
            }
        });
        navigationview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                if (id==R.id.detect_desease){
                    startActivity(new Intent(getApplicationContext(),Crop_Disease_Detector.class));
                } else if (id==R.id.community) {
                    communityFragment();
                } else if (id==R.id.cultivation_tips) {
                    startActivity(new Intent(getApplicationContext(),User_Selected_Crops_Activity.class));
                } else if (id==R.id.profile) {
                    openProfileFragment();
                } else if (id==R.id.logout) {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Pending Logout",Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else if (id==R.id.help) {

                } else if (id==R.id.help) {

                } else if (id==R.id.faq) {

                } else if (id==R.id.share_my_app) {

                }
                return true;
            }
        });


        //This is done to open Home Fragment by default....!
        Home h = new Home();
        Community c = new Community();
        Profile p = new Profile();
        getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer, h).commit();


        bottomNavigationView = findViewById(R.id.btmnavbar);
        bottomNavigationView.setOnItemSelectedListener(new ChipNavigationBar.OnItemSelectedListener() {
            @Override
            public void onItemSelected(int i) {
                if (i==R.id.dashhome){
                    getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer, h).commit();
                }
                else if(i==R.id.dashcommunity){
                    getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer, c).commit();
                }
                else if (i==R.id.dashprofile){
                    getSupportFragmentManager().beginTransaction().replace(R.id.FragmentContainer, p).commit();
                }
            }
        });


    }

    private void communityFragment() {
        Community community = new Community();

        // Get the fragment manager and start a fragment transaction
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        // Replace the existing fragment with the profile fragment
        transaction.replace(R.id.FragmentContainer,community);
        transaction.addToBackStack(null);
        // Commit the transaction
        transaction.commit();
        mwrappering.closeDrawer(GravityCompat.START);
    }

    private void openProfileFragment() {
        Profile profileFragment = new Profile();

        // Get the fragment manager and start a fragment transaction
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        // Replace the existing fragment with the profile fragment
        transaction.replace(R.id.FragmentContainer,profileFragment);

        // Commit the transaction
        transaction.commit();
        mwrappering.closeDrawer(GravityCompat.START);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_REQUEST_CODE && resultCode == RESULT_OK && data != null){
            Uri selectedImageUri = data.getData();
            profileimg.setImageURI(selectedImageUri);

            String mimeType = getContentResolver().getType(selectedImageUri);
            if (mimeType != null && (mimeType.equals("image/png") || mimeType.equals("image/jpeg"))) {
                // Get the file path from the Uri
                String imagePath = getPathFromUri(selectedImageUri);

                // Upload the image to the API endpoint
                if (imagePath != null) {
                    uploadImage(imagePath);
                } else {
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Failed to get image path",Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
            } else {
                Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Please select a PNG or JPG image",Snackbar.LENGTH_LONG);
                snackbar.show();
            }
        }
    }

    private String getPathFromUri(Uri selectedImageUri) {
        String path = null;
        String[] projection = {MediaStore.Images.Media.DATA};
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(selectedImageUri, projection, null, null, null);
        if (cursor != null) {
            int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            cursor.moveToFirst();
            path = cursor.getString(columnIndex);
            cursor.close();
        }
        return path;
    }


    // METHOD TO POST IMAGE TO S3 BUCKET

    private void uploadImage(String imagePath) {

        // Create a File object from the image path
        File imageFile = new File(imagePath);

        // Create a RequestBody from the image file
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/jpeg"), imageFile);

        // Create a MultipartBody.Part from the RequestBody
        MultipartBody.Part imagePart = MultipartBody.Part.createFormData("file", imageFile.getName(), requestBody);
         SharedPreferences sharedPreferences = getSharedPreferences("my_token",Context.MODE_PRIVATE);

        String user_email_or_phone = sharedPreferences.getString("email_or_phone",null);

//        // Make the API call to upload the image

        Call<Common_Exception_Model_Class> call = endpoints.uploadUserImage(imagePart, user_email_or_phone);

         call.enqueue(new Callback<Common_Exception_Model_Class>() {
             @Override
             public void onResponse(Call<Common_Exception_Model_Class> call, Response<Common_Exception_Model_Class> response) {
                 try {
                    if (response.isSuccessful()){
                        Common_Exception_Model_Class common_exception_model_class = response.body();
                        String msg = common_exception_model_class.getMsg();
                        SharedPreferences sharedPreferences = getSharedPreferences("my_token", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("user_img",msg);
                        editor.apply();
                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Image Uploaded Sucessfully",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                    else {
                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Image not Uploaded Sucessfully",Snackbar.LENGTH_LONG);
                        snackbar.show();
                    }
                }
                catch (Exception e){
                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"this is catch"+e.getMessage(),Snackbar.LENGTH_LONG);
                    snackbar.show();
                }
             }

             @Override
             public void onFailure(Call<Common_Exception_Model_Class> call, Throwable t) {

             }
         });
//        call.enqueue(new Callback<Common_Exception_Model_Class>() {
//            @Override
//            public void onResponse(Call<Common_Exception_Model_Class> call, Response<Common_Exception_Model_Class> response) {
//                try {
//                    if (response.isSuccessful()){
//
//
//
//
//                        SharedPreferences sharedPreferences = getSharedPreferences("user_image", Context.MODE_PRIVATE);
//                        SharedPreferences.Editor editor = sharedPreferences.edit();
//                        editor.putString("image",imagePath);
//                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Image Uploaded Sucessfully",Snackbar.LENGTH_LONG);
//                        snackbar.show();
//                    }
//                    else {
//                        Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"Image not Uploaded Sucessfully",Snackbar.LENGTH_LONG);
//                        snackbar.show();
//                    }
//                }
//                catch (Exception e){
//                    Snackbar snackbar = Snackbar.make(findViewById(android.R.id.content),"this is catch"+e.getMessage(),Snackbar.LENGTH_LONG);
//                    snackbar.show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//
//            }
//        });
    }

}