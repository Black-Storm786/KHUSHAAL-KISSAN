package com.example.khushaal_kisaan.Interfaces;

public interface LocaleListener {
    void setLocale(String values);
}
