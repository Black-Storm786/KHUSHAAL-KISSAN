package com.example.khushaal_kisaan.Adaptors;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.example.khushaal_kisaan.Fragments.ByStage;
import com.example.khushaal_kisaan.Fragments.ByTask;

public class MyViewPagerAdapter extends FragmentStateAdapter {

    public MyViewPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        switch (position){
            case 0:
                return new ByTask();
            case 1:
                return new ByStage();
            default:
                return new ByTask();
        }
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
