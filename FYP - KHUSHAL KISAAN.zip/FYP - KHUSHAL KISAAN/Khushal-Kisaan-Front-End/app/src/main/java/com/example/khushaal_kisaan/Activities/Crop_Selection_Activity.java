package com.example.khushaal_kisaan.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Adaptors.Crops_Adaptor;
import com.example.khushaal_kisaan.Interfaces.CropsCount;
import com.example.khushaal_kisaan.ModelClasses.Crops_Model_Class;
import com.example.khushaal_kisaan.R;
import com.google.android.material.button.MaterialButton;


public class Crop_Selection_Activity extends AppCompatActivity implements CropsCount {
    private MaterialButton btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_selection);

        getWindow().setStatusBarColor(ContextCompat.getColor(Crop_Selection_Activity.this, R.color.maingrey_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(Crop_Selection_Activity.this, R.color.mainblue_color));

        RecyclerView recyclerView = findViewById(R.id.crop_list);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        Crops_Model_Class[] myCropsData = new Crops_Model_Class[]{
                new Crops_Model_Class("Cherry","Banana","Apple", R.drawable.cherry,R.drawable.banana,R.drawable.apple),
                new Crops_Model_Class("Mango","Grape","Orange", R.drawable.mango,R.drawable.grape,R.drawable.orange),
                new Crops_Model_Class("Strawberry","Peach","Papaya",R.drawable.strawberry,R.drawable.peach,R.drawable.papaya),
                new Crops_Model_Class("Blueberry","Raspberry","Tomato",R.drawable.blueberry,R.drawable.raspberry,R.drawable.tomato),
                new Crops_Model_Class("Corn","Potato","Capsicum",R.drawable.corn,R.drawable.potato,R.drawable.bellpepper),
                new Crops_Model_Class("Rice","Wheat","Cotton",R.drawable.rice,R.drawable.wheat,R.drawable.cotton)
        };


        Crops_Adaptor my_cropsAdapter = new Crops_Adaptor(myCropsData,Crop_Selection_Activity.this);
        my_cropsAdapter.set_crops_count(this);
        recyclerView.setAdapter(my_cropsAdapter);


        btn = findViewById(R.id.save_button);

        btn.setOnClickListener(v -> {
            Intent myIntent = new Intent(Crop_Selection_Activity.this, DashboardActivity.class);
            Crop_Selection_Activity.this.startActivity(myIntent);
            //finish();
        });
    }


    @Override
    public void set_crops_count(int num) {
        TextView tx = findViewById(R.id.selected_crop_number);
        tx.setText(String.valueOf(num));
    }
}