package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Irrigation_ModelClass {
    Integer image;
    String date;
    String title;
    String subtitle;

    public Irrigation_ModelClass(Integer image, String date, String title, String subtitle) {
        this.image = image;
        this.date = date;
        this.title = title;
        this.subtitle = subtitle;
    }

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
