package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

import java.util.List;

public class WeatherResponse {
    private Coord coord;
    private List<Weather> weather;
    private String base;
    private Main main;
    private int visibility;
    private Wind wind;
    private Clouds clouds;
    private long dt;
    private Sys sys;
    private int timezone;
    private int id;
    private String name;
    private int cod;

    // Getter and setter methods for all the fields

    public Coord getCoord() {
        return coord;
    }

    public List<Weather> getWeather() {
        return weather;
    }

    public String getBase() {
        return base;
    }

    public Main getMain() {
        return main;
    }

    public int getVisibility() {
        return visibility;
    }

    public Wind getWind() {
        return wind;
    }

    public Clouds getClouds() {
        return clouds;
    }

    public long getDt() {
        return dt;
    }

    public Sys getSys() {
        return sys;
    }

    public int getTimezone() {
        return timezone;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getCod() {
        return cod;
    }

    public class Coord {
        private double lon;
        private double lat;

        // Getter and setter methods for lon and lat
    }

    public class Weather {
        private int id;
        private String main;
        private String description;
        private String icon;

        // Getter and setter methods for id, main, description, and icon
    }

    public class Main {
        private double temp;
        private double feels_like;
        private double temp_min;
        private double temp_max;
        private int pressure;
        private int humidity;

        public double getTemp() {
            return temp;
        }

        public double getFeelsLike() {
            return feels_like;
        }

        public double getTempMin() {
            return temp_min;
        }

        public double getTempMax() {
            return temp_max;
        }

        public int getPressure() {
            return pressure;
        }

        public int getHumidity() {
            return humidity;
        }
    }

    public class Wind {
        private double speed;
        private int deg;
        private double gust;

        // Getter and setter methods for speed, deg, and gust
    }

    public class Clouds {
        private int all;

        // Getter and setter methods for all
    }

    public class Sys {
        private int type;
        private int id;
        private String country;
        private long sunrise;
        private long sunset;

        // Getter and setter methods for type, id, country, sunrise, and sunset
    }
}
