package com.example.khushaal_kisaan.Fragments;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.khushaal_kisaan.R;
public class Profile extends Fragment {
    private SharedPreferences sharedPreferences;
    private static final String SHARED_PREFS_KEY = "my_token";
    private static final String DATA_KEY = "data_key";
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);
        sharedPreferences = getActivity().getSharedPreferences(SHARED_PREFS_KEY, Context.MODE_PRIVATE);
        sharedPreferences.getString("user_img",null);
        return view;
    }
}