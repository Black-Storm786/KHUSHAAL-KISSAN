package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Irrigation_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Irrigation_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Irrigation_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView irrigation;
    ArrayList<Irrigation_ModelClass> irrigation_data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_irrigation_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        irrigation.setLayoutManager(linearLayoutManager);
       Irrigation_ModelClass irrigationScreen_modelClass1 = new Irrigation_ModelClass(R.drawable.plant_selection_img2,"3 - 10 APR - CURRENT","Week 1","Make an irrigation plan for your leguminous crops");
        Irrigation_ModelClass irrigationScreen_modelClass2 = new Irrigation_ModelClass(R.drawable.plant_selection_screen_img,"15 - 22 MAY","Week 7","Critical irrigation time");
        irrigation_data.add(irrigationScreen_modelClass1);
        irrigation_data.add(irrigationScreen_modelClass2);
        Irrigation_Adapter irrigation_screen_adapter = new Irrigation_Adapter(getApplicationContext(),irrigation_data);
        irrigation.setAdapter(irrigation_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        irrigation = findViewById(R.id.irrigation);
    }

}