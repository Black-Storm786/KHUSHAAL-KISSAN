package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Monitoring_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Monitoring_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Monitoring_Screen extends AppCompatActivity {
    RecyclerView monitoring;
    ArrayList<Monitoring_ModelClass> monitoring_data = new ArrayList<>();
    ImageView back;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitoring_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        monitoring.setLayoutManager(linearLayoutManager);
        Monitoring_ModelClass monitoring_screen_modelClass = new Monitoring_ModelClass(R.drawable.plant_selection_screen_img,"Monitor fields frequently");
        monitoring_data.add(monitoring_screen_modelClass);
        Monitoring_Adapter monitoringScreenAdapter = new Monitoring_Adapter(getApplicationContext(),monitoring_data);
        monitoring.setAdapter(monitoringScreenAdapter);

    }

    private void Initialization() {
        monitoring = findViewById(R.id.monitoring);
        back = findViewById(R.id.back);

    }
}