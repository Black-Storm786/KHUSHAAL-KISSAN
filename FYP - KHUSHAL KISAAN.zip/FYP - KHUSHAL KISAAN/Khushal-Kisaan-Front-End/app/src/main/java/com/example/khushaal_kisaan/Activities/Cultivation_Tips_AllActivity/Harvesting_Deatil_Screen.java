package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Harvesting_Deatil_Screen extends AppCompatActivity {
    ImageView back,harvesting_readmore_image;
    TextView harvesting_readmore_title,harvesting_readmore_subtitle,harvesting_readmore_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_harvesting_deatil_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        String date = i.getStringExtra("date");
        Integer image = i.getIntExtra("image",0);
        harvesting_readmore_date.setText(date);
        harvesting_readmore_image.setImageResource(image);
        harvesting_readmore_subtitle.setText(subtitle);
        harvesting_readmore_title.setText(title);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        harvesting_readmore_image = findViewById(R.id.harvesting_readmore_image);
        harvesting_readmore_title = findViewById(R.id.harvesting_readmore_title);
        harvesting_readmore_subtitle = findViewById(R.id.harvesting_readmore_subtitle);
        harvesting_readmore_date = findViewById(R.id.harvesting_readmore_date);

    }
}