package com.example.khushaal_kisaan.ModelClasses;

public class Languages_Model_Class  {

    private String language_name1;
    private String language_name2;

    public int getAnim1() {
        return anim1;
    }

    public void setAnim1(int anim1) {
        this.anim1 = anim1;
    }

    public int getAnim2() {
        return anim2;
    }

    public void setAnim2(int anim2) {
        this.anim2 = anim2;
    }

    public int getAnim3() {
        return anim3;
    }

    public void setAnim3(int anim3) {
        this.anim3 = anim3;
    }

    private String language_name3;

    private int anim1;
    private int anim2;
    private int anim3;


    public Languages_Model_Class(String language_name1, String language_name2, String language_name3, int anim1, int anim2, int anim3) {
        this.language_name1 = language_name1;
        this.language_name2 = language_name2;
        this.language_name3 = language_name3;
        this.anim1 = anim1;
        this.anim2 = anim2;
        this.anim3 = anim3;
    }

    public String getLanguage_name1() {
        return language_name1;
    }

    public void setLanguage_name1(String language_name1) {
        this.language_name1 = language_name1;
    }

    public String getLanguage_name2() {
        return language_name2;
    }

    public void setLanguage_name2(String language_name2) {
        this.language_name2 = language_name2;
    }

    public String getLanguage_name3() {
        return language_name3;
    }

    public void setLanguage_name3(String language_name3) {
        this.language_name3 = language_name3;
    }





}
