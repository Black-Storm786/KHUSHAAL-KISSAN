package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Post_Harvest_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Post_Harvest_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Post_Harvest_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView postharvest;
    ArrayList<Post_Harvest_ModelClass> postharvest_data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_harvest_screen);
        Initialization();
        onClickListeners();

    }
    private void onClickListeners() {
        postharvest.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        Post_Harvest_ModelClass post_harvest_modelClass1 = new Post_Harvest_ModelClass(R.drawable.planting_screen_image3,"Threshing dry broad beans");
        Post_Harvest_ModelClass post_harvest_modelClass2 = new Post_Harvest_ModelClass(R.drawable.planting_screen_image2,"Refrigerated storage for French beans");
        Post_Harvest_ModelClass post_harvest_modelClass3 = new Post_Harvest_ModelClass(R.drawable.planting_screen_image1,"Standardization of your leguminous seeds");
        Post_Harvest_ModelClass post_harvest_modelClass4 = new Post_Harvest_ModelClass(R.drawable.plant_selection_img2,"Make sure you know where to sell your harvest");
        postharvest_data.add(post_harvest_modelClass1);
        postharvest_data.add(post_harvest_modelClass2);
        postharvest_data.add(post_harvest_modelClass3);
        postharvest_data.add(post_harvest_modelClass4);
       Post_Harvest_Adapter postHarvest_screen_adapter = new Post_Harvest_Adapter(getApplicationContext(),postharvest_data);
        postharvest.setAdapter(postHarvest_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        postharvest = findViewById(R.id.postharvest);

    }
}