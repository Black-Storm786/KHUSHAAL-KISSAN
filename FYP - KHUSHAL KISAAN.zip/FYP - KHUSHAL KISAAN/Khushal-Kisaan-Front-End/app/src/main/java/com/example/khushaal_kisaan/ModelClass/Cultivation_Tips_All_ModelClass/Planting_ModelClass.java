package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Planting_ModelClass {
    int image;
    String subtitle;

    public Planting_ModelClass(int image, String subtitle) {
        this.image = image;
        this.subtitle = subtitle;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }
}
