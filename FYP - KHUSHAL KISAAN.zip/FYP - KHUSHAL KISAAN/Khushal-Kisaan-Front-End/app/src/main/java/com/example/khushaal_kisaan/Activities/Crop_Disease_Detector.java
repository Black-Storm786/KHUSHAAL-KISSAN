package com.example.khushaal_kisaan.Activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.khushaal_kisaan.R;

import java.io.ByteArrayOutputStream;

public class Crop_Disease_Detector extends AppCompatActivity {
    private static final int CAMERA_REQUEST_CODE = 456;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 789;
    LinearLayout righttick;
    ImageView crop_desease_img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop_disease_detector);
        righttick = findViewById(R.id.righttick);
        getWindow().setStatusBarColor(ContextCompat.getColor(Crop_Disease_Detector.this, R.color.mainblue_color));
        getWindow().setNavigationBarColor(ContextCompat.getColor(Crop_Disease_Detector.this, R.color.mainblue_color));
        crop_desease_img = findViewById(R.id.crop_desease_img);
        righttick.setVisibility(View.GONE);
        crop_desease_img.setVisibility(View.GONE);
        openCamera();
    }

    private void openCamera() {
        if (checkCameraPermission()) {
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
        } else {
            requestCameraPermission();
        }
    }
    private boolean checkCameraPermission() {
        int cameraPermission = checkSelfPermission(android.Manifest.permission.CAMERA);
        return cameraPermission == PackageManager.PERMISSION_GRANTED;
    }


    private void requestCameraPermission() {
        requestPermissions(new String[]{android.Manifest.permission.CAMERA}, CAMERA_PERMISSION_REQUEST_CODE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

          if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK && data!=null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            righttick.setVisibility(View.VISIBLE);
            crop_desease_img.setVisibility(View.VISIBLE);
            Uri photoUri = getImageUri(photo);
            crop_desease_img.setImageURI(photoUri);

        }
    }

    private Uri getImageUri(Bitmap bitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(getContentResolver(), bitmap, "Title", null);
        return Uri.parse(path);
    }

    public void goBack(View view) {
        onBackPressed();
    }
}