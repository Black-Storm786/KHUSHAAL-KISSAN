package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Preventive_Measure_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Preventive_Measure_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Preventive_Measure_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView preventivemeasure;
    ArrayList<Preventive_Measure_ModelClass> preventive_data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preventive_measure_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        preventivemeasure.setLayoutManager(linearLayoutManager);
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass1 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_img2,"Week 1","Prevent leafhoppers in your plants","3 - 10 APR - CURRENT");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass2 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_screen_img,"Week 2","Prevent aphids in your plants","10 - 17 APR");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass3 = new Preventive_Measure_ModelClass(R.drawable.planting_screen_image1,"Week 2","Prevent laf miners in your plants","10 - 17 APR");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass4 = new Preventive_Measure_ModelClass(R.drawable.planting_screen_image2,"Week 3","Prevent bean common mosaic virus on your plants","17 - 24 APR");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass5 = new Preventive_Measure_ModelClass(R.drawable.planting_screen_image3,"Week 4","Prevent flea beetles in your crops","24 - APR - 1 MAY");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass6 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_screen_img,"Week 5","Prevent Cercospora leaf spot in your plants","1 - 8 MAY");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass7 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_img2,"Week 6","Prevent anthracnose in your crop","8 - 15 MAY");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass8 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_screen_img,"Week 7","Prevent blister beetles in your field of legumes","15 - 22 MAY");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass9 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_img2,"Week 8","Prevent spider mites in your field","22 - 29 MAY");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass10 = new Preventive_Measure_ModelClass(R.drawable.planting_screen_image3,"Week 9","Prevent ashy stem blight in your legume plants","29 MAY - 5 JUN");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass11 = new Preventive_Measure_ModelClass(R.drawable.plant_selection_img2,"Week 10","Prevent bacterial blight in your plants","5 - 12 JUN");
        Preventive_Measure_ModelClass preventive_measure_screen_modelClass12 = new Preventive_Measure_ModelClass(R.drawable.planting_screen_image1,"Week 10","Prevent pea pod borers in your fields","5 - 12 JUN");
        preventive_data.add(preventive_measure_screen_modelClass1);
        preventive_data.add(preventive_measure_screen_modelClass2);
        preventive_data.add(preventive_measure_screen_modelClass3);
        preventive_data.add(preventive_measure_screen_modelClass4);
        preventive_data.add(preventive_measure_screen_modelClass5);
        preventive_data.add(preventive_measure_screen_modelClass6);
        preventive_data.add(preventive_measure_screen_modelClass7);
        preventive_data.add(preventive_measure_screen_modelClass8);
        preventive_data.add(preventive_measure_screen_modelClass9);
        preventive_data.add(preventive_measure_screen_modelClass10);
        preventive_data.add(preventive_measure_screen_modelClass11);
        preventive_data.add(preventive_measure_screen_modelClass12);
        Preventive_Measure_Adapter preventive_measure_screen_adapter = new Preventive_Measure_Adapter(getApplicationContext(),preventive_data);
        preventivemeasure.setAdapter(preventive_measure_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        preventivemeasure = findViewById(R.id.preventivemeasure);

    }
}