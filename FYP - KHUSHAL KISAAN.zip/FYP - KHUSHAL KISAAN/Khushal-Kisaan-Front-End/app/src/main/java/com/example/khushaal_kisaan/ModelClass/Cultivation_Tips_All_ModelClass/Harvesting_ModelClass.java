package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Harvesting_ModelClass {
    Integer image;
    String title;
    String subtitle;
    String date;

    public Harvesting_ModelClass(Integer image, String title, String subtitle, String date) {
        this.image = image;
        this.title = title;
        this.subtitle = subtitle;
        this.date = date;
    }

    public Integer getImage() {
        return image;
    }

    public void setImage(Integer image) {
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
