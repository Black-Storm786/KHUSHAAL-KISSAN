package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Planting_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Planting_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Planting_Screen extends AppCompatActivity {
    RecyclerView plantingrecyclerview;
    LinearLayout planting;
    ArrayList<Planting_ModelClass> plantingdata = new ArrayList<>();
    ImageView back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_planting_screen);
        initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        plantingrecyclerview.setLayoutManager(new GridLayoutManager(getApplicationContext(),2));
        Planting_ModelClass planting_screen_modelClass1 = new Planting_ModelClass(R.drawable.planting_screen_image1,"Seed Chemical treatments");
        Planting_ModelClass planting_screen_modelClass2 = new Planting_ModelClass(R.drawable.planting_screen_image2,"Seed biological treatments");
        Planting_ModelClass planting_screen_modelClass3 = new Planting_ModelClass(R.drawable.planting_screen_image3,"Rhizobium seed treatments");
        plantingdata.add(planting_screen_modelClass1);
        plantingdata.add(planting_screen_modelClass2);
        plantingdata.add(planting_screen_modelClass3);


        Planting_Adapter planting_adapter = new Planting_Adapter(getApplicationContext(),plantingdata);
        plantingrecyclerview.setAdapter(planting_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
        planting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Planting_Detail_Screen.class));
            }
        });
    }

    private void initialization() {
        plantingrecyclerview = findViewById(R.id.plantingrecyclerview);
        back = findViewById(R.id.back);
        planting = findViewById(R.id.planting);
    }
}