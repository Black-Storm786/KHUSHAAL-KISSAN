package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Field_Preparation_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Field_Preparation_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Field_Preparation_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView fieldpreparation;
    ArrayList<Field_Preparation_ModelClass> field_preparation_data = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_field_preparation_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        fieldpreparation.setLayoutManager(linearLayoutManager);
        Field_Preparation_ModelClass field_preparation_screen_modelClass1 = new Field_Preparation_ModelClass(R.drawable.plant_selection_screen_img,"2 weeks before seeding","20 - 27 MAR","Prepare fields well in advance of sowing date.");
        Field_Preparation_ModelClass field_preparation_screen_modelClass2 = new Field_Preparation_ModelClass(R.drawable.planting_screen_image3,"week 13","26 JUN - 3 JUL","Start preparing fields again soon after harvest");
        field_preparation_data.add(field_preparation_screen_modelClass1);
        field_preparation_data.add(field_preparation_screen_modelClass2);
        Field_Preparation_Adapter field_preparation_screen_adapter = new Field_Preparation_Adapter(getApplicationContext(),field_preparation_data);
        fieldpreparation.setAdapter(field_preparation_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        fieldpreparation = findViewById(R.id.fieldpreparation);

    }
}