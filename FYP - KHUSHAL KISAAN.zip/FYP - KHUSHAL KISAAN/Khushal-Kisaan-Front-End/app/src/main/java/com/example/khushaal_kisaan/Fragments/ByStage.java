package com.example.khushaal_kisaan.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.By_Stage_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.By_Stage_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class ByStage extends Fragment {
    RecyclerView by_stage_recyclerview;
    ArrayList<By_Stage_ModelClass> preventive_data = new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_by_stage, container, false);
        initialization(view);
        onClickListeners();
        return view;
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL,false);
        by_stage_recyclerview.setLayoutManager(linearLayoutManager);
        By_Stage_ModelClass preventive_measure_screen_modelClass1 = new By_Stage_ModelClass(R.drawable.plant_selection_img2,"Week 1","Prevent leafhoppers in your plants","3 - 10 APR - CURRENT");
        By_Stage_ModelClass preventive_measure_screen_modelClass2 = new By_Stage_ModelClass(R.drawable.plant_selection_screen_img,"Week 2","Prevent aphids in your plants","10 - 17 APR");
        By_Stage_ModelClass preventive_measure_screen_modelClass3 = new By_Stage_ModelClass(R.drawable.planting_screen_image1,"Week 2","Prevent laf miners in your plants","10 - 17 APR");
        By_Stage_ModelClass preventive_measure_screen_modelClass4 = new By_Stage_ModelClass(R.drawable.planting_screen_image2,"Week 3","Prevent bean common mosaic virus on your plants","17 - 24 APR");
        By_Stage_ModelClass preventive_measure_screen_modelClass5 = new By_Stage_ModelClass(R.drawable.planting_screen_image3,"Week 4","Prevent flea beetles in your crops","24 - APR - 1 MAY");
        By_Stage_ModelClass preventive_measure_screen_modelClass6 = new By_Stage_ModelClass(R.drawable.plant_selection_screen_img,"Week 5","Prevent Cercospora leaf spot in your plants","1 - 8 MAY");
        By_Stage_ModelClass preventive_measure_screen_modelClass7 = new By_Stage_ModelClass(R.drawable.plant_selection_img2,"Week 6","Prevent anthracnose in your crop","8 - 15 MAY");
        By_Stage_ModelClass preventive_measure_screen_modelClass8 = new By_Stage_ModelClass(R.drawable.plant_selection_screen_img,"Week 7","Prevent blister beetles in your field of legumes","15 - 22 MAY");
        By_Stage_ModelClass preventive_measure_screen_modelClass9 = new By_Stage_ModelClass(R.drawable.plant_selection_img2,"Week 8","Prevent spider mites in your field","22 - 29 MAY");
        By_Stage_ModelClass preventive_measure_screen_modelClass10 = new By_Stage_ModelClass(R.drawable.planting_screen_image3,"Week 9","Prevent ashy stem blight in your legume plants","29 MAY - 5 JUN");
        By_Stage_ModelClass preventive_measure_screen_modelClass11 = new By_Stage_ModelClass(R.drawable.plant_selection_img2,"Week 10","Prevent bacterial blight in your plants","5 - 12 JUN");
        By_Stage_ModelClass preventive_measure_screen_modelClass12 = new By_Stage_ModelClass(R.drawable.planting_screen_image1,"Week 10","Prevent pea pod borers in your fields","5 - 12 JUN");
        preventive_data.add(preventive_measure_screen_modelClass1);
        preventive_data.add(preventive_measure_screen_modelClass2);
        preventive_data.add(preventive_measure_screen_modelClass3);
        preventive_data.add(preventive_measure_screen_modelClass4);
        preventive_data.add(preventive_measure_screen_modelClass5);
        preventive_data.add(preventive_measure_screen_modelClass6);
        preventive_data.add(preventive_measure_screen_modelClass7);
        preventive_data.add(preventive_measure_screen_modelClass8);
        preventive_data.add(preventive_measure_screen_modelClass9);
        preventive_data.add(preventive_measure_screen_modelClass10);
        preventive_data.add(preventive_measure_screen_modelClass11);
        preventive_data.add(preventive_measure_screen_modelClass12);
        By_Stage_Adapter preventive_measure_screen_adapter = new By_Stage_Adapter(getContext(),preventive_data);
        by_stage_recyclerview.setAdapter(preventive_measure_screen_adapter);
    }

    private void initialization(View view) {
        by_stage_recyclerview = view.findViewById(R.id.by_stage_recyclerview);
    }
}