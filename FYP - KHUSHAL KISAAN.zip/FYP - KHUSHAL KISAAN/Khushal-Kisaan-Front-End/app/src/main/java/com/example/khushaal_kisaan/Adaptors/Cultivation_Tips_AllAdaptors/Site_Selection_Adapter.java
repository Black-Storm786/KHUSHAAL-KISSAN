package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Site_Selection_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Site_Slection_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Site_Selection_Adapter extends RecyclerView.Adapter<Site_Selection_Adapter.ViewHolder> {
    Context context;
    ArrayList<Site_Slection_ModelClass> site_selection_data = new ArrayList<>();

    public Site_Selection_Adapter(Context context, ArrayList<Site_Slection_ModelClass> site_selection_data) {
        this.context = context;
        this.site_selection_data = site_selection_data;
    }

    @NonNull
    @Override
    public Site_Selection_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.site_selection_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Site_Selection_Adapter.ViewHolder holder, int position) {
        holder.siteselectioncard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Site_Selection_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",site_selection_data.get(position).getImage());
                i.putExtra("subtitle",site_selection_data.get(position).getSubtitle());
                i.putExtra("title",site_selection_data.get(position).getTitle());
                i.putExtra("date",site_selection_data.get(position).getDate());
                context.startActivity(i);
            }
        });
        holder.site_selection_date.setText(site_selection_data.get(position).getDate());
        holder.site_selection_subtitle.setText(site_selection_data.get(position).getSubtitle());
        holder.site_selection_title.setText(site_selection_data.get(position).getTitle());
        holder.site_selection_image.setImageResource(site_selection_data.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return site_selection_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout siteselectioncard;
        ImageView site_selection_image;
        TextView site_selection_title,site_selection_date,site_selection_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            siteselectioncard = itemView.findViewById(R.id.siteselectioncard);
            site_selection_date = itemView.findViewById(R.id.site_selection_date);
            site_selection_subtitle = itemView.findViewById(R.id.site_selection_subtitle);
            site_selection_title = itemView.findViewById(R.id.site_selection_title);
            site_selection_image = itemView.findViewById(R.id.site_selection_image);
        }
    }
}
