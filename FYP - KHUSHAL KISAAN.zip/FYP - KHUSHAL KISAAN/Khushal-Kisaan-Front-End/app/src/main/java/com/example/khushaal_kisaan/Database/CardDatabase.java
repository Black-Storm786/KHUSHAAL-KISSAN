package com.example.khushaal_kisaan.Database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.khushaal_kisaan.Interfaces.SelectedCardDao;
import com.example.khushaal_kisaan.ModelClass.SelectedCard;

@Database(entities = SelectedCard.class,version = 1)
public abstract class CardDatabase extends RoomDatabase {
    private static final String DATABASE_NAME = "my_database";

    public abstract SelectedCardDao myDataDao();

    // Create a singleton instance of the database
    private static volatile CardDatabase instance;

    public static synchronized CardDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            CardDatabase.class, DATABASE_NAME)
                    .build();
        }
        return instance;
    }

}
