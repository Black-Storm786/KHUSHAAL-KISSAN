package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Post_Harvest_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Post_Harvest_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Post_Harvest_Adapter extends RecyclerView.Adapter<Post_Harvest_Adapter.ViewHolder> {
    Context context;
    ArrayList<Post_Harvest_ModelClass> postharvest_data = new ArrayList<>();

    public Post_Harvest_Adapter(Context context, ArrayList<Post_Harvest_ModelClass> postharvest_data) {
        this.context = context;
        this.postharvest_data = postharvest_data;
    }

    @NonNull
    @Override
    public Post_Harvest_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.post_harvest_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Post_Harvest_Adapter.ViewHolder holder, int position) {
        holder.postharvestcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Post_Harvest_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",postharvest_data.get(position).getImage());
                i.putExtra("subtitle",postharvest_data.get(position).getSubtitle());
                context.startActivity(i);
            }
        });
        holder.postharvest_image.setImageResource(postharvest_data.get(position).getImage());
        holder.postharvest_subtitle.setText(postharvest_data.get(position).getSubtitle());
    }

    @Override
    public int getItemCount() {
        return postharvest_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout postharvestcard;
        ImageView postharvest_image;
        TextView postharvest_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            postharvestcard = itemView.findViewById(R.id.postharvestcard);
            postharvest_image = itemView.findViewById(R.id.postharvest_image);
            postharvest_subtitle = itemView.findViewById(R.id.postharvest_subtitle);
        }
    }
}
