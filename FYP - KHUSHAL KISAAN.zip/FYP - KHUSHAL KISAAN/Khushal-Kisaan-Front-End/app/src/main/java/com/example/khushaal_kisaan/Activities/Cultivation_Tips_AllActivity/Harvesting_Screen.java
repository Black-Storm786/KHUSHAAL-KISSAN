package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors.Harvesting_Adapter;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Harvesting_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Harvesting_Screen extends AppCompatActivity {
    ImageView back;
    RecyclerView harvesting;
    ArrayList<Harvesting_ModelClass> harvesting_data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_harvesting_screen);
        Initialization();
        onClickListeners();
    }
    private void onClickListeners() {
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.VERTICAL,false);
        harvesting.setLayoutManager(linearLayoutManager);
        Harvesting_ModelClass harvesting_screen_modelClass = new Harvesting_ModelClass(R.drawable.planting_screen_image3,"Week 11","Bean harvest timing","12 - 19 JUN");
        harvesting_data.add(harvesting_screen_modelClass);
        Harvesting_Adapter harvesting_screen_adapter = new Harvesting_Adapter(getApplicationContext(),harvesting_data);
        harvesting.setAdapter(harvesting_screen_adapter);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        harvesting = findViewById(R.id.harvesting);

    }
}