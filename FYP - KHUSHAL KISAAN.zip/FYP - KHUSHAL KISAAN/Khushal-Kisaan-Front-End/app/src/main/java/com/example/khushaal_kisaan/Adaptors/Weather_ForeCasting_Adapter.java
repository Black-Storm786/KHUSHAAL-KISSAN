package com.example.khushaal_kisaan.Adaptors;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.R;

public class Weather_ForeCasting_Adapter extends RecyclerView.Adapter<Weather_ForeCasting_Adapter.ViewHolder>{


    Context context;


    public Weather_ForeCasting_Adapter(Context context) {
        this.context = context;
    }



    @NonNull
    @Override
    public Weather_ForeCasting_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.all_days_weather_card_view,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull Weather_ForeCasting_Adapter.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 3;
    }





    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
        }
    }

}
