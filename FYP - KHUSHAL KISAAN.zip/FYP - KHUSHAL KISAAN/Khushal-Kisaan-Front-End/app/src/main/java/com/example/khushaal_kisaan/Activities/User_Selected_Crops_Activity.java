package com.example.khushaal_kisaan.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.khushaal_kisaan.Adaptors.User_Selected_Crops_Adapter;
import com.example.khushaal_kisaan.Database.CardDatabase;
import com.example.khushaal_kisaan.ModelClass.SelectedCard;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;
import java.util.List;

public class User_Selected_Crops_Activity extends AppCompatActivity {
RecyclerView cropsrecycle;
ImageView gotoselectscreen;
    CardDatabase cardDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selected_crops);
//        cardDatabase = CardDatabase.getDB(getApplicationContext());
//        cardDatabase = CardDatabase.getInstance(getApplicationContext());
        cropsrecycle = findViewById(R.id.cropsrecycle);
        gotoselectscreen = findViewById(R.id.gotoselectscreen);
        gotoselectscreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Crop_Selection_Activity.class));
            }
        });
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(),LinearLayoutManager.HORIZONTAL,false);
        cropsrecycle.setLayoutManager(linearLayoutManager);
        cardDatabase = CardDatabase.getInstance(getApplicationContext());
        new LoadSelectedCardsTask().execute();

//        ArrayList<SelectedCard> userArrayList = (ArrayList<SelectedCard>) cardDatabase.myDataDao().getAllSelectedCards();
//        Toast.makeText(this, "Total objects is " + userArrayList.size(), Toast.LENGTH_SHORT).show();
//        User_Selected_Crops_Adapter user_selected_crops_adapter = new User_Selected_Crops_Adapter(userArrayList);
//        cropsrecycle.setAdapter(user_selected_crops_adapter);

    }

    public void cultivationtips(View view) {
        startActivity(new Intent(getApplicationContext(),Cultivation_Tips_Screen.class));
    }

    private class LoadSelectedCardsTask extends AsyncTask<Void, Void, List<SelectedCard>> {
        @Override
        protected List<SelectedCard> doInBackground(Void... voids) {
            // Perform database operations on a background thread
//            CardDatabase database = CardDatabase.getInstance(User_Selected_Crops_Activity.this);
            return cardDatabase.myDataDao().getAllSelectedCards();
        }

        @Override
        protected void onPostExecute(List<SelectedCard> selectedCards) {
            Toast.makeText(User_Selected_Crops_Activity.this, "Total objects: " + selectedCards.size(), Toast.LENGTH_SHORT).show();
            User_Selected_Crops_Adapter user_selected_crops_adapter = new User_Selected_Crops_Adapter((ArrayList<SelectedCard>) selectedCards,getApplicationContext());
            cropsrecycle.setAdapter(user_selected_crops_adapter);
            // Process the retrieved data
            // ...
        }
    }

    public void goBack(View view) {
        onBackPressed();
    }
}