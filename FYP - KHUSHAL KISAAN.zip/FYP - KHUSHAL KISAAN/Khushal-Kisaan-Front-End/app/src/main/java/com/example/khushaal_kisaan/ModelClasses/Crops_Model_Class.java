package com.example.khushaal_kisaan.ModelClasses;

public class Crops_Model_Class {

    private String crop_name1;
    private String crop_name2;
    private String crop_name3;
    private int img1;
    private int img2;
    private int img3;


    public Crops_Model_Class(String crop_name1, String crop_name2, String crop_name3, int img1, int img2, int img3) {
        this.crop_name1 = crop_name1;
        this.crop_name2 = crop_name2;
        this.crop_name3 = crop_name3;
        this.img1 = img1;
        this.img2 = img2;
        this.img3 = img3;
    }

    public String getCrop_name1() {
        return crop_name1;
    }

    public void setCrop_name1(String crop_name1) {
        this.crop_name1 = crop_name1;
    }

    public String getCrop_name2() {
        return crop_name2;
    }

    public void setCrop_name2(String crop_name2) {
        this.crop_name2 = crop_name2;
    }

    public String getCrop_name3() {
        return crop_name3;
    }

    public void setCrop_name3(String crop_name3) {
        this.crop_name3 = crop_name3;
    }

    public int getImg1() {
        return img1;
    }

    public void setImg1(int img1) {
        this.img1 = img1;
    }

    public int getImg2() {
        return img2;
    }

    public void setImg2(int img2) {
        this.img2 = img2;
    }

    public int getImg3() {
        return img3;
    }

    public void setImg3(int img3) {
        this.img3 = img3;
    }
}
