package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Monitoring_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Monitoring_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Monitoring_Adapter extends RecyclerView.Adapter<Monitoring_Adapter.ViewHolder> {

    Context context;
    ArrayList<Monitoring_ModelClass> monitoring_data = new ArrayList<>();

    public Monitoring_Adapter(Context context, ArrayList<Monitoring_ModelClass> monitoring_data) {
        this.context = context;
        this.monitoring_data = monitoring_data;
    }

    @NonNull
    @Override
    public Monitoring_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.monitoring_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Monitoring_Adapter.ViewHolder holder, int position) {
        holder.monitoringcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Monitoring_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",monitoring_data.get(position).getImage());
                i.putExtra("subtitle",monitoring_data.get(position).getSubtitle());
                context.startActivity(i);
            }
        });
        holder.monitoring_screen_image.setImageResource(monitoring_data.get(position).getImage());
        holder.monitoring_screen_subtitle.setText(monitoring_data.get(position).getSubtitle());
    }

    @Override
    public int getItemCount() {
        return monitoring_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout monitoringcard;
        ImageView monitoring_screen_image;
        TextView monitoring_screen_subtitle;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            monitoringcard = itemView.findViewById(R.id.monitoringcard);
            monitoring_screen_image = itemView.findViewById(R.id.monitoring_screen_image);
            monitoring_screen_subtitle = itemView.findViewById(R.id.monitoring_screen_subtitle);
        }
    }
}
