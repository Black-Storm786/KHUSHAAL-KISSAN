package com.example.khushaal_kisaan.Adaptors;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_Screen;
import com.example.khushaal_kisaan.ModelClass.SelectedCard;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class User_Selected_Crops_Adapter extends RecyclerView.Adapter<User_Selected_Crops_Adapter.ViewHolder> {
    ArrayList<SelectedCard> selectedCards = new ArrayList<>();
    Context context;
    private int selectedItemPosition = -1;

    public User_Selected_Crops_Adapter(ArrayList<SelectedCard> selectedCards, Context context) {
        this.selectedCards = selectedCards;
        this.context = context;
    }

    @NonNull
    @Override
    public User_Selected_Crops_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.user_selected_crops_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull User_Selected_Crops_Adapter.ViewHolder holder, int position) {
      SelectedCard selectedCard = selectedCards.get(position);
        holder.userselectimg.setImageResource(selectedCards.get(position).getCropImage());
          holder.userselectparent.setClickable(true);
//        holder.userselectparent.setOnClickListener(new View.OnClickListener() {
//            private boolean isBackgroundChanged = false;
//            private Drawable defaultBackground = context.getResources().getDrawable(R.drawable.user_select_background3);
//            private Drawable clickedBackground = context.getResources().getDrawable(R.drawable.user_selected_background);
//
//            @Override
//            public void onClick(View view) {
//                if (!isBackgroundChanged) {
//                    holder.userselectparent.setBackground(clickedBackground);
//                    isBackgroundChanged = true;
//                    Intent intent = new Intent(context, Cultivation_Tips_Screen.class);
//                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                    intent.putExtra("title",selectedCards.get(position).getCropName());
//                    intent.putExtra("image",selectedCards.get(position).getCropImage());
//                    context.startActivity(intent);
//
//                } else {
//                    holder.userselectparent.setBackground(defaultBackground);
//                    isBackgroundChanged = false;
//                }
//            }
//        });

        if (selectedItemPosition == position) {
            holder.userselectparent.setBackground(context.getResources().getDrawable(R.drawable.user_selected_background));
        } else {
            holder.userselectparent.setBackground(context.getResources().getDrawable(R.drawable.user_select_background3));
        }

        holder.userselectparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (selectedItemPosition == position) {
                    // If the same item is clicked again, unselect it
                    selectedItemPosition = -1;
                } else {
                    // Set the clicked item as selected
                    selectedItemPosition = position;
                }
                notifyDataSetChanged();

                Intent intent = new Intent(context, Cultivation_Tips_Screen.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("title", selectedCard.getCropName());
                intent.putExtra("image", selectedCard.getCropImage());
                context.startActivity(intent);
            }
        });


    }

    @Override
    public int getItemCount() {
        return selectedCards.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout userselectparent;
        CardView userselectparent1;
        ImageView userselectimg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            userselectimg = itemView.findViewById(R.id.userselectimg);
            userselectparent = itemView.findViewById(R.id.userselectparent);
            userselectparent1 = itemView.findViewById(R.id.userselectparent1);
        }
    }
}
