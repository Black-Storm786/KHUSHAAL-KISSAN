package com.example.khushaal_kisaan.Adaptors.Cultivation_Tips_AllAdaptors;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity.Plant_Training_Detail_Screen;
import com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass.Plant_Training_ModelClass;
import com.example.khushaal_kisaan.R;

import java.util.ArrayList;

public class Plant_Training_Adapter extends RecyclerView.Adapter<Plant_Training_Adapter.ViewHolder> {
    Context context;
    ArrayList<Plant_Training_ModelClass> plant_training_data = new ArrayList<>();

    public Plant_Training_Adapter(Context context, ArrayList<Plant_Training_ModelClass> plant_training_data) {
        this.context = context;
        this.plant_training_data = plant_training_data;
    }

    @NonNull
    @Override
    public Plant_Training_Adapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.plant_training_card,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull Plant_Training_Adapter.ViewHolder holder, int position) {
        holder.planttrainingcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, Plant_Training_Detail_Screen.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image",plant_training_data.get(position).getImage());
                i.putExtra("subtitle",plant_training_data.get(position).getSubtitle());
                context.startActivity(i);
            }
        });
        holder.plant_training_image.setImageResource(plant_training_data.get(position).getImage());
        holder.plant_training_subtitle.setText(plant_training_data.get(position).getSubtitle());
    }

    @Override
    public int getItemCount() {
        return plant_training_data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout planttrainingcard;
        ImageView plant_training_image;
        TextView plant_training_subtitle;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            planttrainingcard = itemView.findViewById(R.id.planttrainingcard);
            plant_training_image = itemView.findViewById(R.id.plant_training_image);
            plant_training_subtitle = itemView.findViewById(R.id.plant_training_subtitle);

        }
    }
}
