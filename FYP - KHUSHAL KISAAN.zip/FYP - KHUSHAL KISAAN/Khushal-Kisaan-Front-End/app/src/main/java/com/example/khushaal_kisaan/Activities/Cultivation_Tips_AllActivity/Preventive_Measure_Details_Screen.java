package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Preventive_Measure_Details_Screen extends AppCompatActivity {
    ImageView back,preventive_measure_readmore_image;
    TextView preventive_measure_readmore_title,preventive_measure_readmore_subtitle,preventive_measure_readmore_date;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preventive_measure_details_screen);
        Initialization();
        onClickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        preventive_measure_readmore_image.setImageResource(image);
        preventive_measure_readmore_subtitle.setText(subtitle);
        preventive_measure_readmore_title.setText(title);
        preventive_measure_readmore_date.setText(date);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        preventive_measure_readmore_image = findViewById(R.id.preventive_measure_readmore_image);
        preventive_measure_readmore_title = findViewById(R.id.preventive_measure_readmore_title);
        preventive_measure_readmore_subtitle = findViewById(R.id.preventive_measure_readmore_subtitle);
        preventive_measure_readmore_date = findViewById(R.id.preventive_measure_readmore_date);


    }
}