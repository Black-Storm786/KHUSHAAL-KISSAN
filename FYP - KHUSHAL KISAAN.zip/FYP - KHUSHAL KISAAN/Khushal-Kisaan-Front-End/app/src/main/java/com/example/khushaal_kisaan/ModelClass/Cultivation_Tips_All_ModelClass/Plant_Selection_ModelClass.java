package com.example.khushaal_kisaan.ModelClass.Cultivation_Tips_All_ModelClass;

public class Plant_Selection_ModelClass {
    int plant_selection_img;
    String plant_selection_subtitle;

    public Plant_Selection_ModelClass(int plant_selection_img, String plant_selection_subtitle) {
        this.plant_selection_img = plant_selection_img;
        this.plant_selection_subtitle = plant_selection_subtitle;
    }

    public int getPlant_selection_img() {
        return plant_selection_img;
    }

    public void setPlant_selection_img(int plant_selection_img) {
        this.plant_selection_img = plant_selection_img;
    }

    public String getPlant_selection_subtitle() {
        return plant_selection_subtitle;
    }

    public void setPlant_selection_subtitle(String plant_selection_subtitle) {
        this.plant_selection_subtitle = plant_selection_subtitle;
    }
}
