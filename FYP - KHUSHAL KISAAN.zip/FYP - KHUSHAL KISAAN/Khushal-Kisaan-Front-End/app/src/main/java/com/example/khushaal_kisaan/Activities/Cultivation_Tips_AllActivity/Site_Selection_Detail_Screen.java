package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Site_Selection_Detail_Screen extends AppCompatActivity {
    ImageView back,site_selection_readmore_image;
    TextView site_selection_readmore_title,site_selection_readmore_subtitle,site_selection_readmore_date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site_selection_detail_screen);
        Initialization();
        onCLickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        Integer image = i.getIntExtra("image",0);
        site_selection_readmore_date.setText(date);
        site_selection_readmore_image.setImageResource(image);
        site_selection_readmore_subtitle.setText(title);
        site_selection_readmore_title.setText(subtitle);
    }
    private void onCLickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void Initialization() {
        back = findViewById(R.id.back);
        site_selection_readmore_image = findViewById(R.id.site_selection_readmore_image);
        site_selection_readmore_title = findViewById(R.id.site_selection_readmore_title);
        site_selection_readmore_subtitle = findViewById(R.id.site_selection_readmore_subtitle);
        site_selection_readmore_date = findViewById(R.id.site_selection_readmore_date);
    }
}