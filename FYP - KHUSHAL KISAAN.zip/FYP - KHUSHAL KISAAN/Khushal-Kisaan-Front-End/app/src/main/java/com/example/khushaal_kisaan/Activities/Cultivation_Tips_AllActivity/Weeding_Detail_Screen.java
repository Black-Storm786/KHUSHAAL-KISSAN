package com.example.khushaal_kisaan.Activities.Cultivation_Tips_AllActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.khushaal_kisaan.R;

public class Weeding_Detail_Screen extends AppCompatActivity {
    ImageView back,weeding_readmore_image;
    TextView weeding_readmore_subtitle,weeding_readmore_title,weeding_readmore_date;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weeding_detail_screen);
        initialization();
        onClickListeners();
        Intent i = getIntent();
        String date = i.getStringExtra("date");
        Integer image = i.getIntExtra("image",0);
        String title = i.getStringExtra("title");
        String subtitle = i.getStringExtra("subtitle");
        weeding_readmore_date.setText(date);
        weeding_readmore_image.setImageResource(image);
        weeding_readmore_subtitle.setText(subtitle);
        weeding_readmore_title.setText(title);
    }
    private void onClickListeners() {
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });
    }

    private void initialization() {
        back = findViewById(R.id.back);
        weeding_readmore_image = findViewById(R.id.weeding_readmore_image);
        weeding_readmore_title = findViewById(R.id.weeding_readmore_title);
        weeding_readmore_subtitle = findViewById(R.id.weeding_readmore_subtitle);
        weeding_readmore_date = findViewById(R.id.weeding_readmore_date);

    }
}