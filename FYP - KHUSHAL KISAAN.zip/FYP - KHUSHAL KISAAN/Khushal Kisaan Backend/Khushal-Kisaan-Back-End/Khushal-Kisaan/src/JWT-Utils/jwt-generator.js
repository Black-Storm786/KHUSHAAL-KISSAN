const jwt = require('jsonwebtoken');

const JWTSecret = "Blackops";
const expiresIn = 6 * 30 * 24 * 60 * 60;
// const expiresIn = 1 * 60;

function TokenGenerator(email_or_phone, password) {
  const token = jwt.sign({ email_or_phone, password }, JWTSecret, { expiresIn });
  return token;
}

module.exports = { TokenGenerator };