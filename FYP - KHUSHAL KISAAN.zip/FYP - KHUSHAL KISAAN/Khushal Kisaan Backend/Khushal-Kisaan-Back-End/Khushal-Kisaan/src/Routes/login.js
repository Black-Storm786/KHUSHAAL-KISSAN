const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");
const bcrypt = require('bcryptjs');
const { TokenGenerator } = require('../JWT-Utils/jwt-generator')



router.use(express.json());



router.get("/", async (req, res) => {
    res.status(405).json(
        {
            "status": "405",
            "msg": "Method Not Allowed!"
        }
    );
});



router.post("/", async (req, res) => {

    try {

        const { email_or_phone, password, tokenExpired } = req.body;

        var signed_token="";

        if(tokenExpired.toLowerCase() === "false"){

            signed_token = TokenGenerator(email_or_phone,password);

            database.query("UPDATE users SET auth_token = ?", [signed_token], (error, result) => {

                if (error) {
                    res.status(500).json(
                        {
                            "status": "500",
                            "msg": "Internal Server Occured While Generating Token!"
                        }
                    )
                }

                else {
                    console.log("Auth Token Updated For User: " + email_or_phone);
                }

            });


        }


        database.query("Select password from users where email_or_phone = ?", [email_or_phone], (error, result) => {

            if (error) {
                res.status(500).json(
                    {
                        "status": "500",
                        "msg": "Internal Server Error!"
                    }
                );
            }

            else {

                if (result.length > 0) {

                    bcrypt.compare(password, result[0].password, async function (err, isMatch) {
                        if (err) {

                            res.status(500).json(
                                {
                                    "status": "500",
                                    "msg": "Internal Server Error!"
                                }
                            );

                        }

                        else if (isMatch) {
                            res.status(200).json(
                                {
                                    "status" : "200",
                                    "msg" : "Login Successful!",
                                    "auth_token" : signed_token
                                }
                            )
                        }
                        else {
                            res.status(403).json(
                                {
                                    "status": "403",
                                    "msg": "Invalid Credentials Provided!"
                                }
                            )
                        }
                    });
                }
                else {
                    res.status(404).json(
                        {
                            "status": "404",
                            "msg": "No Such User Found!"
                        }
                    )
                }

            }

        });

    }
    catch {
        res.status(500).json(
            {
                "status": "500",
                "msg": "Internal Server Error!"
            }
        );
    }
});


module.exports = router;