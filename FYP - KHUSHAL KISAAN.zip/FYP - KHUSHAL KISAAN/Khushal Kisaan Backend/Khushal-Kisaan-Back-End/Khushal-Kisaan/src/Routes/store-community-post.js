const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");
const { v4: uuidv4 } = require('uuid');

router.use(express.json());

router.get("/",(req,res)=>{
    res.status(405).send(
        {
            "status" : "405",
            "msg" : "Method Not Allowed!"
        }
    )
});


router.post("/",async(req,res)=>{

    try {
        const post_to_be_stored = req.body;

        // console.log(post_to_be_stored);

        const post_id = generateUniqueCode();
        const user_email_or_phone = post_to_be_stored.user_email_or_phone;
        const image_one = post_to_be_stored.image_one;
        const image_two = post_to_be_stored.image_two;
        const image_three = post_to_be_stored.image_three;
        const post_title = post_to_be_stored.post_title;
        const post_description = post_to_be_stored.post_description;
        const time_stamp = post_to_be_stored.time_stamp;


        database.query("INSERT INTO community_server_posts (post_id, user_email_or_phone, image_one, image_two, image_three, post_title, post_description, time_stamp) VALUES (?,?,?,?,?,?,?,?)", [post_id, user_email_or_phone, image_one, image_two, image_three, post_title, post_description, time_stamp], (error, result)=>{

            if(error){
                res.status(500).json(
                    {
                        "status":"500",
                        "msg":"Interal Server Error!"
                    }
                )
            }

            else{
                res.status(200).json(
                    {
                        "status":"200",
                        "msg":"Query Posted Successfully!"
                    }
                )
            }

        });


    } catch (error) {
        res.status(500).json(
            {
                "status" : "500",
                "msg" : "Internal Server Error!"
            }
        )
    }

});



// Generate unique code for POST ID
const generateUniqueCode = () => {
    const uuid = uuidv4();
    return uuid;
  };





module.exports = router;