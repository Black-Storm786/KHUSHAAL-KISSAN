const express = require('express');
const router = express.Router();
const axios = require('axios');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../', '.env') });
const apiKey = process.env.OPENWEATHER_API_KEY;
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 1, 
});
const apiUrl = 'https://api.openweathermap.org/data/2.5/forecast';
var latitude;
var longitude;
// Apply security-related middleware
router.use(helmet());
router.use(limiter);
router.get('/', async (req, res) => {
  try {

    latitude = req.query.latitude;
    longitude = req.query.longitude;

    const response = await axios.get(apiUrl, {
      params: {
        lat: latitude,
        lon: longitude,
        appid: apiKey,
      },
    });
  
    // const list_of_weather_data = response.data.list;
    const list_of_weather_data = response.data;
  
    res.send(list_of_weather_data);
    // res.send(list_of_weather_data[0].dt.toString());

} catch (error) {
    // console.error('Error retrieving weather data:', error);
    res.status(500).send('Internal Server Error');
  }
});

module.exports = router;
