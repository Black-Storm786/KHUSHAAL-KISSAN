const express = require('express');
const router = express.Router();
const multer = require('multer');
const database = require("../Database/database_config");

const { S3Client, PutObjectCommand, GetObjectCommand } = require("@aws-sdk/client-s3");
const image_to_be_uploaded = multer({ dest: 'image_to_be_uploaded/' });
const fs = require('fs');

const bucketName = "khushal-kisaan-bucket";
const region = "us-east-1";
const endpointUrl = `https://s3.${region}.amazonaws.com/${bucketName}`;

// create an S3 client object
const s3 = new S3Client({
    region,
    credentials: {
        accessKeyId: "AKIAVUDJSCZFFKKPHJWY",
        secretAccessKey: "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",
    },
});

// Function to upload the image
async function uploadImageToS3(file) {
    const fileStream = fs.createReadStream(file.path);
    const command = new PutObjectCommand({
        Bucket: bucketName,
        Body: fileStream,
        Key: file.originalname,
    });

    try {
        const response = await s3.send(command);
        const location = `${endpointUrl}/${file.originalname}`;
        return location;
    } catch (err) {
        console.error(err, err.stack);
    }
}

// POST API
router.post('/', image_to_be_uploaded.single('file'), async (req, res) => {
    try {
        const file = req.file;
        const emailOrPhone = req.query.email_or_phone; 

        const imageURL = await uploadImageToS3(file);


        database.query("UPDATE users SET user_image =?  WHERE email_or_phone = ?",[imageURL,emailOrPhone], (error, result)=>{

            if(error){
                res.status(500).json(
                    {
                        "status" : "500",
                        "msg" : "Internal Server Error!"
                    }
                )
            }

            else{
                res.status(200).json(
                    {
                        "status" : "200",
                        "msg" : imageURL
                    }
                )
            }

        });


    } catch (error) {
        res.status(401).send("Error: 401 Unauthorized Access!");
    }
});

module.exports = router;
