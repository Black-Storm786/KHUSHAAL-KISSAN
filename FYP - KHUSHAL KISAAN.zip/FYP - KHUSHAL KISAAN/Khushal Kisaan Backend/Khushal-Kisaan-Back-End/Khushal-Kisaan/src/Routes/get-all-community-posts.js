const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");




router.get("/",(req,res)=>{

    try {
        
        var all_posts = [];

        database.query("SELECT t1.*, t2.user_image FROM community_server_posts t1 JOIN users t2 ON t1.user_email_or_phone = t2.email_or_phone",(error,results)=>{

            if(error){
                res.status(500).json(
                    {
                        "status":"500",
                        "msg" : "Internal Server Error!"
                    }
                )
            }


            else{
                if(results.length > 0){

                    for(i=0; i < results.length; i++){
                        const post = 
                        {
                            "post_id" : results[i].post_id,
                            "user_email_or_phone" : results[i].user_email_or_phone,
                            "image_one" : results[i].image_one,    
                            "image_two" : results[i].image_two,    
                            "image_three" : results[i].image_three,    
                            "post_title" : results[i].post_title,    
                            "post_description" : results[i].post_description,    
                            "time_stamp" : results[i].time_stamp,
                            "user_image" : results[i].user_image
                        }

                        all_posts.push(post);
                    }
                    res.status(200).send(all_posts);
                }
                else{
                    res.status(404).json(
                        {
                            "status" : "404",
                            "msg" : "No Posts Found!"
                        }
                    )
                }
            }

        });


    } catch (error) {
        res.status(500).json(
            {
                "status":"500",
                "msg" : "Internal Server Error!"
            }
        )
    }

});






router.post("/", (req,res)=>{

    res.status(405).json(
        {
            "status":"405",
            "msg" : "Method Not Allowed!"
        }
    )
    
});




module.exports = router;