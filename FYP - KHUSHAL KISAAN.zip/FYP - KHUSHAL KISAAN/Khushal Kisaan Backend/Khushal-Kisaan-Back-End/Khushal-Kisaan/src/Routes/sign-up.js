const express = require('express');
const router = express.Router();
const database = require("../Database/database_config");
const bcrypt = require('bcryptjs');
const { TokenGenerator } = require('../JWT-Utils/jwt-generator')


router.use(express.json());


router.get("/", async (req, res) => {
    res.status(405).json(
        {
            "status": "405",
            "msg": "Method Not Allowed!"
        }
    );
});



router.post("/", async (req, res) => {

    try {

        const { username, email_or_phone, password } = req.body;
        const hash = await bcrypt.hash(password, 10);

        const signed_token = TokenGenerator(email_or_phone,password);

        database.query("INSERT into users (username, email_or_phone, password, auth_token) VALUES (?,?,?,?)", [username, email_or_phone, hash, signed_token], (error, result) => {

            if (error) {
                res.status(500).json(
                    {
                        "status": "500",
                        "msg": "Internal Server Error!"
                    }
                );
            }

            else {

                res.status(200).json(
                    {
                        "status" : "200",
                        "msg" : "Sign Up Successful!",
                        "auth_token":signed_token
                    }
                 );
        
            }
        });

    }

    catch {
        res.status(500).json(
            {
                "status": "500",
                "msg": "Internal Server Error!"
            }
        );
    }
});


module.exports = router;