const express = require('express')
const router = express.Router();
const jwt = require('jsonwebtoken')


const JWTSecret = 'Blackops';

router.get('/', async (req, res) => {

    try {
        const authToken = req.query.auth_token;
        var isTokenValid = "false";
        if (!authToken) {
            res.status(400).json(
                {
                    "status": "400",
                    "msg": "No Token Provided!"
                }
            )
        }
        else {

            try {

                const decodedToken = jwt.verify(authToken, JWTSecret);
                const currentTimestamp = Math.floor(Date.now() / 1000);

                    const tokenExpiration = decodedToken.exp;
                    isTokenValid = currentTimestamp < tokenExpiration;

                    res.status(200).json(
                        {
                            "status": "200",
                            "msg": "" + isTokenValid
                        }
                    )

                }
                catch (error) {
                    res.status(401).json(
                        {
                            "status": "401",
                            "msg": "" + isTokenValid
                        }
                    )
                }


        }

    } catch (error) {
        res.status(500).json(
            {
                "status": "500",
                "msg": "Internal Server Error!"
            }
        )
    }

});



router.post("/", (req, res) => {

    res.status(405).json(
        {
            "status": "405",
            "msg": "Method Not Allowed!"
        }
    )
});

module.exports = router;