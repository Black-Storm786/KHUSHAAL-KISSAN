const express = require('express');
const app = express();
const port = 8029;
const version = "1.0";
// const environment = "dev"
const environment = "prod"

const signinRoute = require("../Routes/login");
const signupRoute = require("../Routes/sign-up");
const get_weather_Route = require("../Routes/get-weather");
const token_validator_Route = require("../Routes/token-validator");
const upload_user_image_Route = require("../Routes/upload-user-image");
const get_all_posts_Route = require("../Routes/get-all-community-posts");
const store_community_post_Route = require("../Routes/store-community-post");


//Calling Routes 
app.use("/Login", signinRoute);
app.use("/Sign-up", signupRoute);
app.use("/Get-Weather", get_weather_Route);
app.use("/Validate-Token", token_validator_Route);
app.use("/Upload-User-Image", upload_user_image_Route);
app.use("/Get-All-Community-Posts", get_all_posts_Route);
app.use("/Store-Community-Post", store_community_post_Route);



if (environment === "dev") {

    app.listen(port, () => {
        console.log(`Server is listening at port: ${port}, version: ${version}`);
    });

}

else if (environment === "prod") {

    app.listen(port, "192.168.3.111", () => {
        console.log(`Server is listening at http://192.168.3.111:${port}, version: ${version}`);
    });

}
