const Mysql = require('mysql');
const con = Mysql.createConnection({

    host: 'localhost',
    user: 'root',
    password: '',
    database: 'khushal_kisaan'
});


con.connect(function (err) {
    if (err) { throw err; }
    else { console.log("Database Connected...!"); }
});



module.exports = con;